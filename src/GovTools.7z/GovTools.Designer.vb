﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class GovTools
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(GovTools))
        Me.Radar = New System.Windows.Forms.PictureBox()
        Me.pbTrash = New System.Windows.Forms.PictureBox()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.GroupBox23 = New System.Windows.Forms.GroupBox()
        Me.LinkEx1 = New System.Windows.Forms.LinkLabel()
        Me.cbEx = New System.Windows.Forms.ComboBox()
        Me.lbEx1 = New System.Windows.Forms.Label()
        Me.btnEx = New System.Windows.Forms.Button()
        Me.btnExFile = New System.Windows.Forms.Button()
        Me.tbEx = New System.Windows.Forms.TextBox()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.btnMaskStart = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.lbMask1 = New System.Windows.Forms.Label()
        Me.tbMaskPara = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lbMask16 = New System.Windows.Forms.Label()
        Me.lbMask10 = New System.Windows.Forms.Label()
        Me.tbMask11 = New System.Windows.Forms.TextBox()
        Me.tbMask12 = New System.Windows.Forms.TextBox()
        Me.lbMask11 = New System.Windows.Forms.Label()
        Me.lbMask14 = New System.Windows.Forms.Label()
        Me.lbMask12 = New System.Windows.Forms.Label()
        Me.lbMask2 = New System.Windows.Forms.Label()
        Me.tbMask14 = New System.Windows.Forms.TextBox()
        Me.cbMask2 = New System.Windows.Forms.CheckBox()
        Me.tbMask13 = New System.Windows.Forms.TextBox()
        Me.cbMask1 = New System.Windows.Forms.CheckBox()
        Me.lbMask15 = New System.Windows.Forms.Label()
        Me.lbMask8 = New System.Windows.Forms.Label()
        Me.lbMask13 = New System.Windows.Forms.Label()
        Me.tbMask8 = New System.Windows.Forms.TextBox()
        Me.lbMask7 = New System.Windows.Forms.Label()
        Me.tbMask9 = New System.Windows.Forms.TextBox()
        Me.lbMask6 = New System.Windows.Forms.Label()
        Me.lbMask9 = New System.Windows.Forms.Label()
        Me.lbMask5 = New System.Windows.Forms.Label()
        Me.cbMask4 = New System.Windows.Forms.CheckBox()
        Me.lbMask4 = New System.Windows.Forms.Label()
        Me.lbMask3 = New System.Windows.Forms.Label()
        Me.tbMask6 = New System.Windows.Forms.TextBox()
        Me.cbMask3 = New System.Windows.Forms.CheckBox()
        Me.tbMask5 = New System.Windows.Forms.TextBox()
        Me.tbMask3 = New System.Windows.Forms.TextBox()
        Me.tbMask4 = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GroupBoxPrince2 = New System.Windows.Forms.GroupBox()
        Me.lbPrinceMB = New System.Windows.Forms.Label()
        Me.lbPrincePass = New System.Windows.Forms.Label()
        Me.tbPRINCEMB = New System.Windows.Forms.TextBox()
        Me.tbPRINCEPass = New System.Windows.Forms.TextBox()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.btnPrinceCalc = New System.Windows.Forms.Button()
        Me.labPrince = New System.Windows.Forms.Label()
        Me.GroupBoxPrince1 = New System.Windows.Forms.GroupBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.CheckBoxPrince = New System.Windows.Forms.CheckBox()
        Me.lbprince2 = New System.Windows.Forms.Label()
        Me.lbPrincemin = New System.Windows.Forms.Label()
        Me.lbPrincemax = New System.Windows.Forms.Label()
        Me.lbPrincemin2 = New System.Windows.Forms.Label()
        Me.lbPrincemax2 = New System.Windows.Forms.Label()
        Me.lbPrince1 = New System.Windows.Forms.Label()
        Me.tbPrinceMinLen = New System.Windows.Forms.TextBox()
        Me.tbPrinceMaxLen = New System.Windows.Forms.TextBox()
        Me.tbPrinceMinPerm = New System.Windows.Forms.TextBox()
        Me.tbPrinceMaxPerm = New System.Windows.Forms.TextBox()
        Me.GroupBoxPrince3 = New System.Windows.Forms.GroupBox()
        Me.btnPrinceDefault = New System.Windows.Forms.Button()
        Me.btnPrinceFile = New System.Windows.Forms.Button()
        Me.tbPrince = New System.Windows.Forms.TextBox()
        Me.btnPrinceSTART = New System.Windows.Forms.Button()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.GroupBoxCUPP = New System.Windows.Forms.GroupBox()
        Me.btnCupp = New System.Windows.Forms.Button()
        Me.lbCupp1 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.GroupBoxWord3 = New System.Windows.Forms.GroupBox()
        Me.Up = New System.Windows.Forms.CheckBox()
        Me.Cap = New System.Windows.Forms.CheckBox()
        Me.Leet = New System.Windows.Forms.CheckBox()
        Me.lbWordall = New System.Windows.Forms.Label()
        Me.lbWordfirst = New System.Windows.Forms.Label()
        Me.lbWordleet = New System.Windows.Forms.Label()
        Me.lbWordmax = New System.Windows.Forms.Label()
        Me.lbWordmin = New System.Windows.Forms.Label()
        Me.lbWordperm = New System.Windows.Forms.Label()
        Me.Perm = New System.Windows.Forms.TextBox()
        Me.MinL = New System.Windows.Forms.TextBox()
        Me.MaxL = New System.Windows.Forms.TextBox()
        Me.GroupBoxWord4 = New System.Windows.Forms.GroupBox()
        Me.tbWordStandard = New System.Windows.Forms.TextBox()
        Me.GroupBoxWord2 = New System.Windows.Forms.GroupBox()
        Me.tbWord45 = New System.Windows.Forms.TextBox()
        Me.tbWord40 = New System.Windows.Forms.TextBox()
        Me.lbWordInfos = New System.Windows.Forms.Label()
        Me.tbWord36 = New System.Windows.Forms.TextBox()
        Me.tbWord44 = New System.Windows.Forms.TextBox()
        Me.tbWord37 = New System.Windows.Forms.TextBox()
        Me.tbWord38 = New System.Windows.Forms.TextBox()
        Me.tbWord43 = New System.Windows.Forms.TextBox()
        Me.tbWord39 = New System.Windows.Forms.TextBox()
        Me.tbWord42 = New System.Windows.Forms.TextBox()
        Me.tbWord41 = New System.Windows.Forms.TextBox()
        Me.GroupBoxWord1 = New System.Windows.Forms.GroupBox()
        Me.lbWord1 = New System.Windows.Forms.Label()
        Me.tbWord35 = New System.Windows.Forms.TextBox()
        Me.tbWord30 = New System.Windows.Forms.TextBox()
        Me.tbWord25 = New System.Windows.Forms.TextBox()
        Me.lbWordBirthyear = New System.Windows.Forms.Label()
        Me.tbWord20 = New System.Windows.Forms.TextBox()
        Me.tbWord34 = New System.Windows.Forms.TextBox()
        Me.tbWord29 = New System.Windows.Forms.TextBox()
        Me.tbWord24 = New System.Windows.Forms.TextBox()
        Me.tbWord19 = New System.Windows.Forms.TextBox()
        Me.tbWord14 = New System.Windows.Forms.TextBox()
        Me.tbWord9 = New System.Windows.Forms.TextBox()
        Me.tbWord4 = New System.Windows.Forms.TextBox()
        Me.lbWordBirthday = New System.Windows.Forms.Label()
        Me.tbWord15 = New System.Windows.Forms.TextBox()
        Me.tbWord33 = New System.Windows.Forms.TextBox()
        Me.tbWord28 = New System.Windows.Forms.TextBox()
        Me.tbWord23 = New System.Windows.Forms.TextBox()
        Me.tbWord18 = New System.Windows.Forms.TextBox()
        Me.tbWord13 = New System.Windows.Forms.TextBox()
        Me.tbWord8 = New System.Windows.Forms.TextBox()
        Me.tbWord3 = New System.Windows.Forms.TextBox()
        Me.lbWordSurname = New System.Windows.Forms.Label()
        Me.tbWord10 = New System.Windows.Forms.TextBox()
        Me.tbWord32 = New System.Windows.Forms.TextBox()
        Me.tbWord27 = New System.Windows.Forms.TextBox()
        Me.tbWord22 = New System.Windows.Forms.TextBox()
        Me.tbWord17 = New System.Windows.Forms.TextBox()
        Me.tbWord12 = New System.Windows.Forms.TextBox()
        Me.tbWord7 = New System.Windows.Forms.TextBox()
        Me.tbWord2 = New System.Windows.Forms.TextBox()
        Me.lbWordName = New System.Windows.Forms.Label()
        Me.lbWordNickname = New System.Windows.Forms.Label()
        Me.tbWord5 = New System.Windows.Forms.TextBox()
        Me.tbWord31 = New System.Windows.Forms.TextBox()
        Me.tbWord26 = New System.Windows.Forms.TextBox()
        Me.tbWord21 = New System.Windows.Forms.TextBox()
        Me.tbWord16 = New System.Windows.Forms.TextBox()
        Me.tbWord11 = New System.Windows.Forms.TextBox()
        Me.tbWord6 = New System.Windows.Forms.TextBox()
        Me.lbWordFather = New System.Windows.Forms.Label()
        Me.lbWordMother = New System.Windows.Forms.Label()
        Me.lbWordChild3 = New System.Windows.Forms.Label()
        Me.lbWordChild2 = New System.Windows.Forms.Label()
        Me.lbWordChild1 = New System.Windows.Forms.Label()
        Me.lbWordWife = New System.Windows.Forms.Label()
        Me.lbWordTarget = New System.Windows.Forms.Label()
        Me.tbWord1 = New System.Windows.Forms.TextBox()
        Me.btnWordOpen = New System.Windows.Forms.Button()
        Me.btnWordStart = New System.Windows.Forms.Button()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.GroupBoxcewl2 = New System.Windows.Forms.GroupBox()
        Me.lbcewl3 = New System.Windows.Forms.Label()
        Me.tbCewlPage = New System.Windows.Forms.TextBox()
        Me.lbcewl2 = New System.Windows.Forms.Label()
        Me.btnCewlStart = New System.Windows.Forms.Button()
        Me.GroupBoxCewl1 = New System.Windows.Forms.GroupBox()
        Me.lbCewlInstall = New System.Windows.Forms.Label()
        Me.lbCewl1 = New System.Windows.Forms.Label()
        Me.btnCewlInstall = New System.Windows.Forms.Button()
        Me.btnCewlLinux = New System.Windows.Forms.Button()
        Me.GroupBoxcewl3 = New System.Windows.Forms.GroupBox()
        Me.lbcewl4 = New System.Windows.Forms.Label()
        Me.lbcewl5 = New System.Windows.Forms.Label()
        Me.tbCewlWord = New System.Windows.Forms.TextBox()
        Me.tbCewlSpider = New System.Windows.Forms.TextBox()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.GroupBoxComb2 = New System.Windows.Forms.GroupBox()
        Me.pbLen = New System.Windows.Forms.PictureBox()
        Me.lbLen4 = New System.Windows.Forms.Label()
        Me.LenMaxTxb = New System.Windows.Forms.TextBox()
        Me.btnLen = New System.Windows.Forms.Button()
        Me.lbLen3 = New System.Windows.Forms.Label()
        Me.lbLen2 = New System.Windows.Forms.Label()
        Me.LenMinTxb = New System.Windows.Forms.TextBox()
        Me.lbLen1 = New System.Windows.Forms.Label()
        Me.LenTxb = New System.Windows.Forms.TextBox()
        Me.GroupBoxComb1 = New System.Windows.Forms.GroupBox()
        Me.pbCombinator3 = New System.Windows.Forms.PictureBox()
        Me.pbCombinator2 = New System.Windows.Forms.PictureBox()
        Me.pbCombinator1 = New System.Windows.Forms.PictureBox()
        Me.lbComb4 = New System.Windows.Forms.Label()
        Me.File3Txb = New System.Windows.Forms.TextBox()
        Me.btnCombinator = New System.Windows.Forms.Button()
        Me.lbComb3 = New System.Windows.Forms.Label()
        Me.lbComb2 = New System.Windows.Forms.Label()
        Me.File2Txb = New System.Windows.Forms.TextBox()
        Me.lbComb1 = New System.Windows.Forms.Label()
        Me.File1Txb = New System.Windows.Forms.TextBox()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBoxWordT3 = New System.Windows.Forms.GroupBox()
        Me.cbWordScanner = New System.Windows.Forms.CheckBox()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.pbWordScanner = New System.Windows.Forms.PictureBox()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.tbWordScanner2 = New System.Windows.Forms.TextBox()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.tbWordScanner = New System.Windows.Forms.TextBox()
        Me.lbWordT3 = New System.Windows.Forms.Label()
        Me.btnWordScanner = New System.Windows.Forms.Button()
        Me.GroupBoxWordT2 = New System.Windows.Forms.GroupBox()
        Me.btnWordAnalyserEx = New System.Windows.Forms.Button()
        Me.lbWordT2 = New System.Windows.Forms.Label()
        Me.btnWordAnalyser = New System.Windows.Forms.Button()
        Me.GroupBoxWordT1 = New System.Windows.Forms.GroupBox()
        Me.lbWordT1 = New System.Windows.Forms.Label()
        Me.btnWordMask = New System.Windows.Forms.Button()
        Me.ListBoxWTL = New System.Windows.Forms.ListBox()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.lbDup1 = New System.Windows.Forms.Label()
        Me.Duptxb = New System.Windows.Forms.TextBox()
        Me.btnDup = New System.Windows.Forms.Button()
        Me.DupTargettxb = New System.Windows.Forms.TextBox()
        Me.pbDup2 = New System.Windows.Forms.PictureBox()
        Me.lbDup2 = New System.Windows.Forms.Label()
        Me.pbDup1 = New System.Windows.Forms.PictureBox()
        Me.lbDup3 = New System.Windows.Forms.Label()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.lbHash2 = New System.Windows.Forms.Label()
        Me.lbHash1 = New System.Windows.Forms.Label()
        Me.lblHashGen = New System.Windows.Forms.Label()
        Me.btnHashGen = New System.Windows.Forms.Button()
        Me.HashIn = New System.Windows.Forms.TextBox()
        Me.HashOUT = New System.Windows.Forms.TextBox()
        Me.TabPage11 = New System.Windows.Forms.TabPage()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.lbBulk = New System.Windows.Forms.Label()
        Me.GroupBoxBulk1 = New System.Windows.Forms.GroupBox()
        Me.pbBulk1 = New System.Windows.Forms.PictureBox()
        Me.cbBulk1 = New System.Windows.Forms.CheckBox()
        Me.cbBulk2 = New System.Windows.Forms.CheckBox()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.btnBulkStart = New System.Windows.Forms.Button()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.lbBulk1 = New System.Windows.Forms.Label()
        Me.tbBulkImage = New System.Windows.Forms.TextBox()
        Me.tbBulkmax = New System.Windows.Forms.TextBox()
        Me.lbBulk2 = New System.Windows.Forms.Label()
        Me.tbBulkmin = New System.Windows.Forms.TextBox()
        Me.lbBulk3 = New System.Windows.Forms.Label()
        Me.pbGER = New System.Windows.Forms.PictureBox()
        Me.pbENG = New System.Windows.Forms.PictureBox()
        Me.pbAbout = New System.Windows.Forms.PictureBox()
        Me.pbGovC = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        CType(Me.Radar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbTrash, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.GroupBox23.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBoxPrince2.SuspendLayout()
        Me.GroupBoxPrince1.SuspendLayout()
        Me.GroupBoxPrince3.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.GroupBoxCUPP.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.GroupBoxWord3.SuspendLayout()
        Me.GroupBoxWord4.SuspendLayout()
        Me.GroupBoxWord2.SuspendLayout()
        Me.GroupBoxWord1.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.GroupBoxcewl2.SuspendLayout()
        Me.GroupBoxCewl1.SuspendLayout()
        Me.GroupBoxcewl3.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.GroupBoxComb2.SuspendLayout()
        CType(Me.pbLen, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBoxComb1.SuspendLayout()
        CType(Me.pbCombinator3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbCombinator2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbCombinator1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage8.SuspendLayout()
        Me.GroupBoxWordT3.SuspendLayout()
        CType(Me.pbWordScanner, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBoxWordT2.SuspendLayout()
        Me.GroupBoxWordT1.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        CType(Me.pbDup2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbDup1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage10.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.TabPage11.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBoxBulk1.SuspendLayout()
        CType(Me.pbBulk1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbGER, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbENG, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbAbout, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbGovC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Radar
        '
        Me.Radar.BackColor = System.Drawing.Color.Black
        Me.Radar.Image = CType(resources.GetObject("Radar.Image"), System.Drawing.Image)
        Me.Radar.Location = New System.Drawing.Point(11, 265)
        Me.Radar.Name = "Radar"
        Me.Radar.Size = New System.Drawing.Size(29, 34)
        Me.Radar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Radar.TabIndex = 71
        Me.Radar.TabStop = False
        Me.Radar.Visible = False
        '
        'pbTrash
        '
        Me.pbTrash.BackColor = System.Drawing.Color.Transparent
        Me.pbTrash.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pbTrash.Image = CType(resources.GetObject("pbTrash.Image"), System.Drawing.Image)
        Me.pbTrash.Location = New System.Drawing.Point(6, 12)
        Me.pbTrash.Name = "pbTrash"
        Me.pbTrash.Size = New System.Drawing.Size(43, 28)
        Me.pbTrash.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbTrash.TabIndex = 72
        Me.pbTrash.TabStop = False
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Controls.Add(Me.TabPage9)
        Me.TabControl1.Controls.Add(Me.TabPage10)
        Me.TabControl1.Controls.Add(Me.TabPage11)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(51, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(802, 580)
        Me.TabControl1.TabIndex = 70
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.GroupBox23)
        Me.TabPage7.Location = New System.Drawing.Point(4, 24)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(794, 552)
        Me.TabPage7.TabIndex = 11
        Me.TabPage7.Text = "Extractor"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'GroupBox23
        '
        Me.GroupBox23.Controls.Add(Me.LinkEx1)
        Me.GroupBox23.Controls.Add(Me.cbEx)
        Me.GroupBox23.Controls.Add(Me.lbEx1)
        Me.GroupBox23.Controls.Add(Me.btnEx)
        Me.GroupBox23.Controls.Add(Me.btnExFile)
        Me.GroupBox23.Controls.Add(Me.tbEx)
        Me.GroupBox23.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox23.Location = New System.Drawing.Point(16, 17)
        Me.GroupBox23.Name = "GroupBox23"
        Me.GroupBox23.Size = New System.Drawing.Size(557, 172)
        Me.GroupBox23.TabIndex = 69
        Me.GroupBox23.TabStop = False
        Me.GroupBox23.Text = "Hash-Extractor"
        '
        'LinkEx1
        '
        Me.LinkEx1.AutoSize = True
        Me.LinkEx1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkEx1.Location = New System.Drawing.Point(10, 125)
        Me.LinkEx1.Name = "LinkEx1"
        Me.LinkEx1.Size = New System.Drawing.Size(230, 16)
        Me.LinkEx1.TabIndex = 68
        Me.LinkEx1.TabStop = True
        Me.LinkEx1.Text = "Hashtype not found? Then click here! "
        '
        'cbEx
        '
        Me.cbEx.BackColor = System.Drawing.Color.White
        Me.cbEx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbEx.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbEx.FormattingEnabled = True
        Me.cbEx.Items.AddRange(New Object() {"7zip", "APFS (Apple MacBooks)", "Bitcoin-Wallet", "Bitlocker", "eCryptfs", "Electrum-Wallet", "Ethereum (MyEtherWallet.com / Keystore-File)", "iTune Backup (iPhone)", "LibreOffice", "Linux Login Password", "Litecoin-Wallet", "LUKS (Linux Unified Key System)", "Office (Word, Excel, etc.)", "PDF", "RAR", "VeraCrypt / TrueCrypt (File)", "VeraCrypt / TrueCrypt (Partition)", "VeraCrypt / TrueVrypt (Hidden Partition)", "Windows Login Password", "ZIP"})
        Me.cbEx.Location = New System.Drawing.Point(141, 41)
        Me.cbEx.Name = "cbEx"
        Me.cbEx.Size = New System.Drawing.Size(391, 24)
        Me.cbEx.TabIndex = 0
        '
        'lbEx1
        '
        Me.lbEx1.AutoSize = True
        Me.lbEx1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbEx1.Location = New System.Drawing.Point(10, 44)
        Me.lbEx1.Name = "lbEx1"
        Me.lbEx1.Size = New System.Drawing.Size(73, 16)
        Me.lbEx1.TabIndex = 67
        Me.lbEx1.Text = "File format:"
        '
        'btnEx
        '
        Me.btnEx.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnEx.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEx.Location = New System.Drawing.Point(434, 115)
        Me.btnEx.Name = "btnEx"
        Me.btnEx.Size = New System.Drawing.Size(98, 26)
        Me.btnEx.TabIndex = 4
        Me.btnEx.Text = "START"
        Me.btnEx.UseVisualStyleBackColor = False
        '
        'btnExFile
        '
        Me.btnExFile.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnExFile.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExFile.Location = New System.Drawing.Point(13, 77)
        Me.btnExFile.Name = "btnExFile"
        Me.btnExFile.Size = New System.Drawing.Size(102, 22)
        Me.btnExFile.TabIndex = 1
        Me.btnExFile.Text = "Select file"
        Me.btnExFile.UseVisualStyleBackColor = False
        '
        'tbEx
        '
        Me.tbEx.BackColor = System.Drawing.Color.White
        Me.tbEx.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbEx.Location = New System.Drawing.Point(141, 77)
        Me.tbEx.Name = "tbEx"
        Me.tbEx.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.tbEx.Size = New System.Drawing.Size(391, 22)
        Me.tbEx.TabIndex = 2
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.btnMaskStart)
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 24)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(794, 552)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Maskprozessor"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'btnMaskStart
        '
        Me.btnMaskStart.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnMaskStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMaskStart.ForeColor = System.Drawing.SystemColors.InfoText
        Me.btnMaskStart.Location = New System.Drawing.Point(495, 424)
        Me.btnMaskStart.Name = "btnMaskStart"
        Me.btnMaskStart.Size = New System.Drawing.Size(95, 27)
        Me.btnMaskStart.TabIndex = 40
        Me.btnMaskStart.Text = "START"
        Me.btnMaskStart.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.PictureBox8)
        Me.GroupBox2.Controls.Add(Me.lbMask1)
        Me.GroupBox2.Controls.Add(Me.tbMaskPara)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(18, 19)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(572, 78)
        Me.GroupBox2.TabIndex = 27
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Maskprocessor"
        '
        'PictureBox8
        '
        Me.PictureBox8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox8.Image = CType(resources.GetObject("PictureBox8.Image"), System.Drawing.Image)
        Me.PictureBox8.Location = New System.Drawing.Point(534, 33)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(25, 21)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox8.TabIndex = 49
        Me.PictureBox8.TabStop = False
        '
        'lbMask1
        '
        Me.lbMask1.AutoSize = True
        Me.lbMask1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMask1.Location = New System.Drawing.Point(14, 36)
        Me.lbMask1.Name = "lbMask1"
        Me.lbMask1.Size = New System.Drawing.Size(147, 16)
        Me.lbMask1.TabIndex = 4
        Me.lbMask1.Text = "Command-Parameters:"
        '
        'tbMaskPara
        '
        Me.tbMaskPara.BackColor = System.Drawing.SystemColors.MenuText
        Me.tbMaskPara.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbMaskPara.ForeColor = System.Drawing.SystemColors.Window
        Me.tbMaskPara.Location = New System.Drawing.Point(167, 33)
        Me.tbMaskPara.Name = "tbMaskPara"
        Me.tbMaskPara.Size = New System.Drawing.Size(361, 22)
        Me.tbMaskPara.TabIndex = 1
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lbMask16)
        Me.GroupBox1.Controls.Add(Me.lbMask10)
        Me.GroupBox1.Controls.Add(Me.tbMask11)
        Me.GroupBox1.Controls.Add(Me.tbMask12)
        Me.GroupBox1.Controls.Add(Me.lbMask11)
        Me.GroupBox1.Controls.Add(Me.lbMask14)
        Me.GroupBox1.Controls.Add(Me.lbMask12)
        Me.GroupBox1.Controls.Add(Me.lbMask2)
        Me.GroupBox1.Controls.Add(Me.tbMask14)
        Me.GroupBox1.Controls.Add(Me.cbMask2)
        Me.GroupBox1.Controls.Add(Me.tbMask13)
        Me.GroupBox1.Controls.Add(Me.cbMask1)
        Me.GroupBox1.Controls.Add(Me.lbMask15)
        Me.GroupBox1.Controls.Add(Me.lbMask8)
        Me.GroupBox1.Controls.Add(Me.lbMask13)
        Me.GroupBox1.Controls.Add(Me.tbMask8)
        Me.GroupBox1.Controls.Add(Me.lbMask7)
        Me.GroupBox1.Controls.Add(Me.tbMask9)
        Me.GroupBox1.Controls.Add(Me.lbMask6)
        Me.GroupBox1.Controls.Add(Me.lbMask9)
        Me.GroupBox1.Controls.Add(Me.lbMask5)
        Me.GroupBox1.Controls.Add(Me.cbMask4)
        Me.GroupBox1.Controls.Add(Me.lbMask4)
        Me.GroupBox1.Controls.Add(Me.lbMask3)
        Me.GroupBox1.Controls.Add(Me.tbMask6)
        Me.GroupBox1.Controls.Add(Me.cbMask3)
        Me.GroupBox1.Controls.Add(Me.tbMask5)
        Me.GroupBox1.Controls.Add(Me.tbMask3)
        Me.GroupBox1.Controls.Add(Me.tbMask4)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(18, 103)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(572, 306)
        Me.GroupBox1.TabIndex = 25
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Settings"
        '
        'lbMask16
        '
        Me.lbMask16.AutoSize = True
        Me.lbMask16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMask16.Location = New System.Drawing.Point(426, 222)
        Me.lbMask16.Name = "lbMask16"
        Me.lbMask16.Size = New System.Drawing.Size(130, 16)
        Me.lbMask16.TabIndex = 32
        Me.lbMask16.Text = "(only words or digits)"
        '
        'lbMask10
        '
        Me.lbMask10.AutoSize = True
        Me.lbMask10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMask10.Location = New System.Drawing.Point(14, 222)
        Me.lbMask10.Name = "lbMask10"
        Me.lbMask10.Size = New System.Drawing.Size(126, 16)
        Me.lbMask10.TabIndex = 24
        Me.lbMask10.Text = "Start / Stop position:"
        '
        'tbMask11
        '
        Me.tbMask11.BackColor = System.Drawing.Color.White
        Me.tbMask11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbMask11.Location = New System.Drawing.Point(167, 219)
        Me.tbMask11.Name = "tbMask11"
        Me.tbMask11.Size = New System.Drawing.Size(120, 22)
        Me.tbMask11.TabIndex = 25
        Me.tbMask11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbMask12
        '
        Me.tbMask12.BackColor = System.Drawing.Color.White
        Me.tbMask12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbMask12.Location = New System.Drawing.Point(330, 219)
        Me.tbMask12.Name = "tbMask12"
        Me.tbMask12.Size = New System.Drawing.Size(90, 22)
        Me.tbMask12.TabIndex = 26
        Me.tbMask12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbMask11
        '
        Me.lbMask11.AutoSize = True
        Me.lbMask11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMask11.Location = New System.Drawing.Point(293, 222)
        Me.lbMask11.Name = "lbMask11"
        Me.lbMask11.Size = New System.Drawing.Size(31, 16)
        Me.lbMask11.TabIndex = 27
        Me.lbMask11.Text = "until"
        '
        'lbMask14
        '
        Me.lbMask14.AutoSize = True
        Me.lbMask14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMask14.Location = New System.Drawing.Point(14, 276)
        Me.lbMask14.Name = "lbMask14"
        Me.lbMask14.Size = New System.Drawing.Size(84, 16)
        Me.lbMask14.TabIndex = 23
        Me.lbMask14.Text = "Occur Chars:"
        '
        'lbMask12
        '
        Me.lbMask12.AutoSize = True
        Me.lbMask12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMask12.Location = New System.Drawing.Point(14, 248)
        Me.lbMask12.Name = "lbMask12"
        Me.lbMask12.Size = New System.Drawing.Size(95, 16)
        Me.lbMask12.TabIndex = 22
        Me.lbMask12.Text = "Multiple Chars:"
        '
        'lbMask2
        '
        Me.lbMask2.AutoSize = True
        Me.lbMask2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMask2.Location = New System.Drawing.Point(14, 28)
        Me.lbMask2.Name = "lbMask2"
        Me.lbMask2.Size = New System.Drawing.Size(89, 16)
        Me.lbMask2.TabIndex = 3
        Me.lbMask2.Text = "Creation-Typ:"
        '
        'tbMask14
        '
        Me.tbMask14.BackColor = System.Drawing.Color.White
        Me.tbMask14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbMask14.Location = New System.Drawing.Point(167, 273)
        Me.tbMask14.Name = "tbMask14"
        Me.tbMask14.Size = New System.Drawing.Size(33, 22)
        Me.tbMask14.TabIndex = 31
        Me.tbMask14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'cbMask2
        '
        Me.cbMask2.AutoSize = True
        Me.cbMask2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbMask2.Location = New System.Drawing.Point(254, 27)
        Me.cbMask2.Name = "cbMask2"
        Me.cbMask2.Size = New System.Drawing.Size(55, 20)
        Me.cbMask2.TabIndex = 2
        Me.cbMask2.Text = "Rule"
        Me.cbMask2.UseVisualStyleBackColor = True
        '
        'tbMask13
        '
        Me.tbMask13.BackColor = System.Drawing.Color.White
        Me.tbMask13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbMask13.Location = New System.Drawing.Point(167, 245)
        Me.tbMask13.Name = "tbMask13"
        Me.tbMask13.Size = New System.Drawing.Size(33, 22)
        Me.tbMask13.TabIndex = 30
        Me.tbMask13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'cbMask1
        '
        Me.cbMask1.AutoSize = True
        Me.cbMask1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbMask1.Location = New System.Drawing.Point(167, 27)
        Me.cbMask1.Name = "cbMask1"
        Me.cbMask1.Size = New System.Drawing.Size(76, 20)
        Me.cbMask1.TabIndex = 1
        Me.cbMask1.Text = "Wordlist"
        Me.cbMask1.UseVisualStyleBackColor = True
        '
        'lbMask15
        '
        Me.lbMask15.AutoSize = True
        Me.lbMask15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMask15.Location = New System.Drawing.Point(212, 276)
        Me.lbMask15.Name = "lbMask15"
        Me.lbMask15.Size = New System.Drawing.Size(322, 16)
        Me.lbMask15.TabIndex = 19
        Me.lbMask15.Text = "(max. Numbers of occurrence of a characters / min=2)"
        '
        'lbMask8
        '
        Me.lbMask8.AutoSize = True
        Me.lbMask8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMask8.Location = New System.Drawing.Point(14, 83)
        Me.lbMask8.Name = "lbMask8"
        Me.lbMask8.Size = New System.Drawing.Size(113, 16)
        Me.lbMask8.TabIndex = 2
        Me.lbMask8.Text = "Searches-Length:"
        '
        'lbMask13
        '
        Me.lbMask13.AutoSize = True
        Me.lbMask13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMask13.Location = New System.Drawing.Point(212, 248)
        Me.lbMask13.Name = "lbMask13"
        Me.lbMask13.Size = New System.Drawing.Size(341, 16)
        Me.lbMask13.TabIndex = 18
        Me.lbMask13.Text = "(max. Numbers of multiple sequential characters / min=2)"
        '
        'tbMask8
        '
        Me.tbMask8.BackColor = System.Drawing.Color.White
        Me.tbMask8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbMask8.Location = New System.Drawing.Point(167, 80)
        Me.tbMask8.Name = "tbMask8"
        Me.tbMask8.Size = New System.Drawing.Size(33, 22)
        Me.tbMask8.TabIndex = 14
        Me.tbMask8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbMask7
        '
        Me.lbMask7.AutoSize = True
        Me.lbMask7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMask7.Location = New System.Drawing.Point(14, 195)
        Me.lbMask7.Name = "lbMask7"
        Me.lbMask7.Size = New System.Drawing.Size(67, 16)
        Me.lbMask7.TabIndex = 17
        Me.lbMask7.Text = "Charset 4:"
        '
        'tbMask9
        '
        Me.tbMask9.BackColor = System.Drawing.Color.White
        Me.tbMask9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbMask9.Location = New System.Drawing.Point(254, 80)
        Me.tbMask9.Name = "tbMask9"
        Me.tbMask9.Size = New System.Drawing.Size(33, 22)
        Me.tbMask9.TabIndex = 15
        Me.tbMask9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbMask6
        '
        Me.lbMask6.AutoSize = True
        Me.lbMask6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMask6.Location = New System.Drawing.Point(14, 167)
        Me.lbMask6.Name = "lbMask6"
        Me.lbMask6.Size = New System.Drawing.Size(67, 16)
        Me.lbMask6.TabIndex = 16
        Me.lbMask6.Text = "Charset 3:"
        '
        'lbMask9
        '
        Me.lbMask9.AutoSize = True
        Me.lbMask9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMask9.Location = New System.Drawing.Point(212, 83)
        Me.lbMask9.Name = "lbMask9"
        Me.lbMask9.Size = New System.Drawing.Size(31, 16)
        Me.lbMask9.TabIndex = 6
        Me.lbMask9.Text = "until"
        '
        'lbMask5
        '
        Me.lbMask5.AutoSize = True
        Me.lbMask5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMask5.Location = New System.Drawing.Point(14, 139)
        Me.lbMask5.Name = "lbMask5"
        Me.lbMask5.Size = New System.Drawing.Size(67, 16)
        Me.lbMask5.TabIndex = 15
        Me.lbMask5.Text = "Charset 2:"
        '
        'cbMask4
        '
        Me.cbMask4.AutoSize = True
        Me.cbMask4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbMask4.Location = New System.Drawing.Point(302, 52)
        Me.cbMask4.Name = "cbMask4"
        Me.cbMask4.Size = New System.Drawing.Size(194, 20)
        Me.cbMask4.TabIndex = 4
        Me.cbMask4.Text = "Only calculate combinations"
        Me.cbMask4.UseVisualStyleBackColor = True
        '
        'lbMask4
        '
        Me.lbMask4.AutoSize = True
        Me.lbMask4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMask4.Location = New System.Drawing.Point(14, 111)
        Me.lbMask4.Name = "lbMask4"
        Me.lbMask4.Size = New System.Drawing.Size(67, 16)
        Me.lbMask4.TabIndex = 14
        Me.lbMask4.Text = "Charset 1:"
        '
        'lbMask3
        '
        Me.lbMask3.AutoSize = True
        Me.lbMask3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMask3.Location = New System.Drawing.Point(14, 53)
        Me.lbMask3.Name = "lbMask3"
        Me.lbMask3.Size = New System.Drawing.Size(49, 16)
        Me.lbMask3.TabIndex = 8
        Me.lbMask3.Text = "Output:"
        '
        'tbMask6
        '
        Me.tbMask6.BackColor = System.Drawing.Color.White
        Me.tbMask6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbMask6.Location = New System.Drawing.Point(167, 192)
        Me.tbMask6.Name = "tbMask6"
        Me.tbMask6.Size = New System.Drawing.Size(391, 22)
        Me.tbMask6.TabIndex = 13
        '
        'cbMask3
        '
        Me.cbMask3.AutoSize = True
        Me.cbMask3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbMask3.Location = New System.Drawing.Point(167, 52)
        Me.cbMask3.Name = "cbMask3"
        Me.cbMask3.Size = New System.Drawing.Size(129, 20)
        Me.cbMask3.TabIndex = 3
        Me.cbMask3.Text = "Create Output-file"
        Me.cbMask3.UseVisualStyleBackColor = True
        '
        'tbMask5
        '
        Me.tbMask5.BackColor = System.Drawing.Color.White
        Me.tbMask5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbMask5.Location = New System.Drawing.Point(167, 164)
        Me.tbMask5.Name = "tbMask5"
        Me.tbMask5.Size = New System.Drawing.Size(391, 22)
        Me.tbMask5.TabIndex = 12
        '
        'tbMask3
        '
        Me.tbMask3.BackColor = System.Drawing.Color.White
        Me.tbMask3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbMask3.Location = New System.Drawing.Point(167, 108)
        Me.tbMask3.Name = "tbMask3"
        Me.tbMask3.Size = New System.Drawing.Size(391, 22)
        Me.tbMask3.TabIndex = 10
        '
        'tbMask4
        '
        Me.tbMask4.BackColor = System.Drawing.Color.White
        Me.tbMask4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbMask4.Location = New System.Drawing.Point(167, 136)
        Me.tbMask4.Name = "tbMask4"
        Me.tbMask4.Size = New System.Drawing.Size(391, 22)
        Me.tbMask4.TabIndex = 11
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.GroupBoxPrince2)
        Me.TabPage2.Controls.Add(Me.labPrince)
        Me.TabPage2.Controls.Add(Me.GroupBoxPrince1)
        Me.TabPage2.Controls.Add(Me.GroupBoxPrince3)
        Me.TabPage2.Location = New System.Drawing.Point(4, 24)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(794, 552)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "PRINCE"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'GroupBoxPrince2
        '
        Me.GroupBoxPrince2.Controls.Add(Me.lbPrinceMB)
        Me.GroupBoxPrince2.Controls.Add(Me.lbPrincePass)
        Me.GroupBoxPrince2.Controls.Add(Me.tbPRINCEMB)
        Me.GroupBoxPrince2.Controls.Add(Me.tbPRINCEPass)
        Me.GroupBoxPrince2.Controls.Add(Me.RichTextBox1)
        Me.GroupBoxPrince2.Controls.Add(Me.btnPrinceCalc)
        Me.GroupBoxPrince2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxPrince2.Location = New System.Drawing.Point(23, 299)
        Me.GroupBoxPrince2.Name = "GroupBoxPrince2"
        Me.GroupBoxPrince2.Size = New System.Drawing.Size(284, 122)
        Me.GroupBoxPrince2.TabIndex = 70
        Me.GroupBoxPrince2.TabStop = False
        Me.GroupBoxPrince2.Text = "Calculate Keyspace"
        '
        'lbPrinceMB
        '
        Me.lbPrinceMB.AutoSize = True
        Me.lbPrinceMB.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbPrinceMB.Location = New System.Drawing.Point(191, 86)
        Me.lbPrinceMB.Name = "lbPrinceMB"
        Me.lbPrinceMB.Size = New System.Drawing.Size(93, 16)
        Me.lbPrinceMB.TabIndex = 67
        Me.lbPrinceMB.Text = "Wordlist in MB"
        '
        'lbPrincePass
        '
        Me.lbPrincePass.AutoSize = True
        Me.lbPrincePass.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbPrincePass.Location = New System.Drawing.Point(191, 59)
        Me.lbPrincePass.Name = "lbPrincePass"
        Me.lbPrincePass.Size = New System.Drawing.Size(75, 16)
        Me.lbPrincePass.TabIndex = 66
        Me.lbPrincePass.Text = "Passwords"
        '
        'tbPRINCEMB
        '
        Me.tbPRINCEMB.BackColor = System.Drawing.SystemColors.InfoText
        Me.tbPRINCEMB.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPRINCEMB.ForeColor = System.Drawing.Color.LawnGreen
        Me.tbPRINCEMB.Location = New System.Drawing.Point(14, 83)
        Me.tbPRINCEMB.Name = "tbPRINCEMB"
        Me.tbPRINCEMB.Size = New System.Drawing.Size(171, 22)
        Me.tbPRINCEMB.TabIndex = 21
        Me.tbPRINCEMB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbPRINCEPass
        '
        Me.tbPRINCEPass.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.tbPRINCEPass.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPRINCEPass.ForeColor = System.Drawing.Color.LawnGreen
        Me.tbPRINCEPass.Location = New System.Drawing.Point(14, 57)
        Me.tbPRINCEPass.Name = "tbPRINCEPass"
        Me.tbPRINCEPass.Size = New System.Drawing.Size(171, 22)
        Me.tbPRINCEPass.TabIndex = 20
        Me.tbPRINCEPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.RichTextBox1.ForeColor = System.Drawing.Color.Chartreuse
        Me.RichTextBox1.Location = New System.Drawing.Point(14, 56)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(171, 21)
        Me.RichTextBox1.TabIndex = 64
        Me.RichTextBox1.Text = ""
        Me.RichTextBox1.Visible = False
        '
        'btnPrinceCalc
        '
        Me.btnPrinceCalc.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnPrinceCalc.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrinceCalc.Location = New System.Drawing.Point(14, 28)
        Me.btnPrinceCalc.Name = "btnPrinceCalc"
        Me.btnPrinceCalc.Size = New System.Drawing.Size(171, 23)
        Me.btnPrinceCalc.TabIndex = 6
        Me.btnPrinceCalc.Text = "Calculate"
        Me.btnPrinceCalc.UseVisualStyleBackColor = False
        '
        'labPrince
        '
        Me.labPrince.AutoSize = True
        Me.labPrince.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labPrince.Location = New System.Drawing.Point(20, 27)
        Me.labPrince.Name = "labPrince"
        Me.labPrince.Size = New System.Drawing.Size(689, 48)
        Me.labPrince.TabIndex = 68
        Me.labPrince.Text = resources.GetString("labPrince.Text")
        '
        'GroupBoxPrince1
        '
        Me.GroupBoxPrince1.Controls.Add(Me.Label31)
        Me.GroupBoxPrince1.Controls.Add(Me.CheckBoxPrince)
        Me.GroupBoxPrince1.Controls.Add(Me.lbprince2)
        Me.GroupBoxPrince1.Controls.Add(Me.lbPrincemin)
        Me.GroupBoxPrince1.Controls.Add(Me.lbPrincemax)
        Me.GroupBoxPrince1.Controls.Add(Me.lbPrincemin2)
        Me.GroupBoxPrince1.Controls.Add(Me.lbPrincemax2)
        Me.GroupBoxPrince1.Controls.Add(Me.lbPrince1)
        Me.GroupBoxPrince1.Controls.Add(Me.tbPrinceMinLen)
        Me.GroupBoxPrince1.Controls.Add(Me.tbPrinceMaxLen)
        Me.GroupBoxPrince1.Controls.Add(Me.tbPrinceMinPerm)
        Me.GroupBoxPrince1.Controls.Add(Me.tbPrinceMaxPerm)
        Me.GroupBoxPrince1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxPrince1.Location = New System.Drawing.Point(20, 91)
        Me.GroupBoxPrince1.Name = "GroupBoxPrince1"
        Me.GroupBoxPrince1.Size = New System.Drawing.Size(287, 202)
        Me.GroupBoxPrince1.TabIndex = 67
        Me.GroupBoxPrince1.TabStop = False
        Me.GroupBoxPrince1.Text = "Parameters"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(14, 220)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(0, 16)
        Me.Label31.TabIndex = 17
        '
        'CheckBoxPrince
        '
        Me.CheckBoxPrince.AutoSize = True
        Me.CheckBoxPrince.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBoxPrince.Location = New System.Drawing.Point(19, 165)
        Me.CheckBoxPrince.Name = "CheckBoxPrince"
        Me.CheckBoxPrince.Size = New System.Drawing.Size(205, 20)
        Me.CheckBoxPrince.TabIndex = 5
        Me.CheckBoxPrince.Text = "Opposite case of the first letter"
        Me.CheckBoxPrince.UseVisualStyleBackColor = True
        '
        'lbprince2
        '
        Me.lbprince2.AutoSize = True
        Me.lbprince2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbprince2.Location = New System.Drawing.Point(16, 95)
        Me.lbprince2.Name = "lbprince2"
        Me.lbprince2.Size = New System.Drawing.Size(94, 16)
        Me.lbprince2.TabIndex = 15
        Me.lbprince2.Text = "Passw. Length"
        '
        'lbPrincemin
        '
        Me.lbPrincemin.AutoSize = True
        Me.lbPrincemin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbPrincemin.Location = New System.Drawing.Point(16, 60)
        Me.lbPrincemin.Name = "lbPrincemin"
        Me.lbPrincemin.Size = New System.Drawing.Size(29, 16)
        Me.lbPrincemin.TabIndex = 14
        Me.lbPrincemin.Text = "min"
        '
        'lbPrincemax
        '
        Me.lbPrincemax.AutoSize = True
        Me.lbPrincemax.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbPrincemax.Location = New System.Drawing.Point(104, 60)
        Me.lbPrincemax.Name = "lbPrincemax"
        Me.lbPrincemax.Size = New System.Drawing.Size(33, 16)
        Me.lbPrincemax.TabIndex = 13
        Me.lbPrincemax.Text = "max"
        '
        'lbPrincemin2
        '
        Me.lbPrincemin2.AutoSize = True
        Me.lbPrincemin2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbPrincemin2.Location = New System.Drawing.Point(16, 129)
        Me.lbPrincemin2.Name = "lbPrincemin2"
        Me.lbPrincemin2.Size = New System.Drawing.Size(29, 16)
        Me.lbPrincemin2.TabIndex = 12
        Me.lbPrincemin2.Text = "min"
        '
        'lbPrincemax2
        '
        Me.lbPrincemax2.AutoSize = True
        Me.lbPrincemax2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbPrincemax2.Location = New System.Drawing.Point(104, 129)
        Me.lbPrincemax2.Name = "lbPrincemax2"
        Me.lbPrincemax2.Size = New System.Drawing.Size(33, 16)
        Me.lbPrincemax2.TabIndex = 11
        Me.lbPrincemax2.Text = "max"
        '
        'lbPrince1
        '
        Me.lbPrince1.AutoSize = True
        Me.lbPrince1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbPrince1.Location = New System.Drawing.Point(14, 29)
        Me.lbPrince1.Name = "lbPrince1"
        Me.lbPrince1.Size = New System.Drawing.Size(151, 16)
        Me.lbPrince1.TabIndex = 10
        Me.lbPrince1.Text = "Number of Permutations"
        '
        'tbPrinceMinLen
        '
        Me.tbPrinceMinLen.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPrinceMinLen.Location = New System.Drawing.Point(45, 126)
        Me.tbPrinceMinLen.Name = "tbPrinceMinLen"
        Me.tbPrinceMinLen.Size = New System.Drawing.Size(48, 22)
        Me.tbPrinceMinLen.TabIndex = 3
        Me.tbPrinceMinLen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbPrinceMaxLen
        '
        Me.tbPrinceMaxLen.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPrinceMaxLen.Location = New System.Drawing.Point(140, 126)
        Me.tbPrinceMaxLen.Name = "tbPrinceMaxLen"
        Me.tbPrinceMaxLen.Size = New System.Drawing.Size(48, 22)
        Me.tbPrinceMaxLen.TabIndex = 4
        Me.tbPrinceMaxLen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbPrinceMinPerm
        '
        Me.tbPrinceMinPerm.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPrinceMinPerm.Location = New System.Drawing.Point(45, 57)
        Me.tbPrinceMinPerm.Name = "tbPrinceMinPerm"
        Me.tbPrinceMinPerm.Size = New System.Drawing.Size(48, 22)
        Me.tbPrinceMinPerm.TabIndex = 1
        Me.tbPrinceMinPerm.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbPrinceMaxPerm
        '
        Me.tbPrinceMaxPerm.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPrinceMaxPerm.Location = New System.Drawing.Point(140, 57)
        Me.tbPrinceMaxPerm.Name = "tbPrinceMaxPerm"
        Me.tbPrinceMaxPerm.Size = New System.Drawing.Size(48, 22)
        Me.tbPrinceMaxPerm.TabIndex = 2
        Me.tbPrinceMaxPerm.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBoxPrince3
        '
        Me.GroupBoxPrince3.Controls.Add(Me.btnPrinceDefault)
        Me.GroupBoxPrince3.Controls.Add(Me.btnPrinceFile)
        Me.GroupBoxPrince3.Controls.Add(Me.tbPrince)
        Me.GroupBoxPrince3.Controls.Add(Me.btnPrinceSTART)
        Me.GroupBoxPrince3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxPrince3.Location = New System.Drawing.Point(326, 91)
        Me.GroupBoxPrince3.Name = "GroupBoxPrince3"
        Me.GroupBoxPrince3.Size = New System.Drawing.Size(383, 330)
        Me.GroupBoxPrince3.TabIndex = 66
        Me.GroupBoxPrince3.TabStop = False
        Me.GroupBoxPrince3.Text = "Input"
        '
        'btnPrinceDefault
        '
        Me.btnPrinceDefault.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnPrinceDefault.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrinceDefault.Location = New System.Drawing.Point(181, 275)
        Me.btnPrinceDefault.Name = "btnPrinceDefault"
        Me.btnPrinceDefault.Size = New System.Drawing.Size(75, 23)
        Me.btnPrinceDefault.TabIndex = 10
        Me.btnPrinceDefault.Text = "Default"
        Me.btnPrinceDefault.UseVisualStyleBackColor = False
        '
        'btnPrinceFile
        '
        Me.btnPrinceFile.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnPrinceFile.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrinceFile.Location = New System.Drawing.Point(100, 275)
        Me.btnPrinceFile.Name = "btnPrinceFile"
        Me.btnPrinceFile.Size = New System.Drawing.Size(75, 23)
        Me.btnPrinceFile.TabIndex = 9
        Me.btnPrinceFile.Text = "Open File"
        Me.btnPrinceFile.UseVisualStyleBackColor = False
        '
        'tbPrince
        '
        Me.tbPrince.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.tbPrince.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPrince.ForeColor = System.Drawing.Color.LawnGreen
        Me.tbPrince.Location = New System.Drawing.Point(15, 26)
        Me.tbPrince.Multiline = True
        Me.tbPrince.Name = "tbPrince"
        Me.tbPrince.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tbPrince.Size = New System.Drawing.Size(349, 243)
        Me.tbPrince.TabIndex = 0
        '
        'btnPrinceSTART
        '
        Me.btnPrinceSTART.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnPrinceSTART.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrinceSTART.Location = New System.Drawing.Point(262, 276)
        Me.btnPrinceSTART.Name = "btnPrinceSTART"
        Me.btnPrinceSTART.Size = New System.Drawing.Size(102, 23)
        Me.btnPrinceSTART.TabIndex = 0
        Me.btnPrinceSTART.Text = "START"
        Me.btnPrinceSTART.UseVisualStyleBackColor = False
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.GroupBoxCUPP)
        Me.TabPage3.Location = New System.Drawing.Point(4, 24)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(794, 552)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "CUPP"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'GroupBoxCUPP
        '
        Me.GroupBoxCUPP.Controls.Add(Me.btnCupp)
        Me.GroupBoxCUPP.Controls.Add(Me.lbCupp1)
        Me.GroupBoxCUPP.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxCUPP.Location = New System.Drawing.Point(20, 28)
        Me.GroupBoxCUPP.Name = "GroupBoxCUPP"
        Me.GroupBoxCUPP.Size = New System.Drawing.Size(673, 131)
        Me.GroupBoxCUPP.TabIndex = 0
        Me.GroupBoxCUPP.TabStop = False
        Me.GroupBoxCUPP.Text = "CUPP – Common User Passwords Profiler"
        '
        'btnCupp
        '
        Me.btnCupp.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnCupp.Location = New System.Drawing.Point(27, 92)
        Me.btnCupp.Name = "btnCupp"
        Me.btnCupp.Size = New System.Drawing.Size(75, 23)
        Me.btnCupp.TabIndex = 1
        Me.btnCupp.Text = "START"
        Me.btnCupp.UseVisualStyleBackColor = False
        '
        'lbCupp1
        '
        Me.lbCupp1.AutoSize = True
        Me.lbCupp1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbCupp1.Location = New System.Drawing.Point(24, 38)
        Me.lbCupp1.Name = "lbCupp1"
        Me.lbCupp1.Size = New System.Drawing.Size(478, 32)
        Me.lbCupp1.TabIndex = 0
        Me.lbCupp1.Text = "Cupp is also a wordlister that creates large wordlists from subjketive informatio" &
    "n " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "about the target person."
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.GroupBoxWord3)
        Me.TabPage4.Controls.Add(Me.GroupBoxWord4)
        Me.TabPage4.Controls.Add(Me.GroupBoxWord2)
        Me.TabPage4.Controls.Add(Me.GroupBoxWord1)
        Me.TabPage4.Controls.Add(Me.btnWordOpen)
        Me.TabPage4.Controls.Add(Me.btnWordStart)
        Me.TabPage4.Location = New System.Drawing.Point(4, 24)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(794, 552)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Wordlister"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'GroupBoxWord3
        '
        Me.GroupBoxWord3.Controls.Add(Me.Up)
        Me.GroupBoxWord3.Controls.Add(Me.Cap)
        Me.GroupBoxWord3.Controls.Add(Me.Leet)
        Me.GroupBoxWord3.Controls.Add(Me.lbWordall)
        Me.GroupBoxWord3.Controls.Add(Me.lbWordfirst)
        Me.GroupBoxWord3.Controls.Add(Me.lbWordleet)
        Me.GroupBoxWord3.Controls.Add(Me.lbWordmax)
        Me.GroupBoxWord3.Controls.Add(Me.lbWordmin)
        Me.GroupBoxWord3.Controls.Add(Me.lbWordperm)
        Me.GroupBoxWord3.Controls.Add(Me.Perm)
        Me.GroupBoxWord3.Controls.Add(Me.MinL)
        Me.GroupBoxWord3.Controls.Add(Me.MaxL)
        Me.GroupBoxWord3.Location = New System.Drawing.Point(22, 426)
        Me.GroupBoxWord3.Name = "GroupBoxWord3"
        Me.GroupBoxWord3.Size = New System.Drawing.Size(306, 108)
        Me.GroupBoxWord3.TabIndex = 3
        Me.GroupBoxWord3.TabStop = False
        Me.GroupBoxWord3.Text = "Parameter"
        '
        'Up
        '
        Me.Up.AutoSize = True
        Me.Up.Checked = True
        Me.Up.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Up.Location = New System.Drawing.Point(162, 81)
        Me.Up.Name = "Up"
        Me.Up.Size = New System.Drawing.Size(15, 14)
        Me.Up.TabIndex = 64
        Me.Up.UseVisualStyleBackColor = True
        '
        'Cap
        '
        Me.Cap.AutoSize = True
        Me.Cap.Checked = True
        Me.Cap.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Cap.Location = New System.Drawing.Point(162, 54)
        Me.Cap.Name = "Cap"
        Me.Cap.Size = New System.Drawing.Size(15, 14)
        Me.Cap.TabIndex = 63
        Me.Cap.UseVisualStyleBackColor = True
        '
        'Leet
        '
        Me.Leet.AutoSize = True
        Me.Leet.Checked = True
        Me.Leet.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Leet.Location = New System.Drawing.Point(162, 28)
        Me.Leet.Name = "Leet"
        Me.Leet.Size = New System.Drawing.Size(15, 14)
        Me.Leet.TabIndex = 62
        Me.Leet.UseVisualStyleBackColor = True
        '
        'lbWordall
        '
        Me.lbWordall.AutoSize = True
        Me.lbWordall.Location = New System.Drawing.Point(183, 81)
        Me.lbWordall.Name = "lbWordall"
        Me.lbWordall.Size = New System.Drawing.Size(67, 15)
        Me.lbWordall.TabIndex = 61
        Me.lbWordall.Text = "Uppercase"
        '
        'lbWordfirst
        '
        Me.lbWordfirst.AutoSize = True
        Me.lbWordfirst.Location = New System.Drawing.Point(183, 54)
        Me.lbWordfirst.Name = "lbWordfirst"
        Me.lbWordfirst.Size = New System.Drawing.Size(75, 15)
        Me.lbWordfirst.TabIndex = 60
        Me.lbWordfirst.Text = "Capital letter"
        '
        'lbWordleet
        '
        Me.lbWordleet.AutoSize = True
        Me.lbWordleet.Location = New System.Drawing.Point(183, 28)
        Me.lbWordleet.Name = "lbWordleet"
        Me.lbWordleet.Size = New System.Drawing.Size(31, 15)
        Me.lbWordleet.TabIndex = 59
        Me.lbWordleet.Text = "Leet"
        '
        'lbWordmax
        '
        Me.lbWordmax.AutoSize = True
        Me.lbWordmax.Location = New System.Drawing.Point(6, 81)
        Me.lbWordmax.Name = "lbWordmax"
        Me.lbWordmax.Size = New System.Drawing.Size(75, 15)
        Me.lbWordmax.TabIndex = 58
        Me.lbWordmax.Text = "max. Length"
        '
        'lbWordmin
        '
        Me.lbWordmin.AutoSize = True
        Me.lbWordmin.Location = New System.Drawing.Point(6, 54)
        Me.lbWordmin.Name = "lbWordmin"
        Me.lbWordmin.Size = New System.Drawing.Size(72, 15)
        Me.lbWordmin.TabIndex = 57
        Me.lbWordmin.Text = "min. Length"
        '
        'lbWordperm
        '
        Me.lbWordperm.AutoSize = True
        Me.lbWordperm.Location = New System.Drawing.Point(6, 28)
        Me.lbWordperm.Name = "lbWordperm"
        Me.lbWordperm.Size = New System.Drawing.Size(80, 15)
        Me.lbWordperm.TabIndex = 45
        Me.lbWordperm.Text = "Permutations"
        '
        'Perm
        '
        Me.Perm.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Perm.Location = New System.Drawing.Point(113, 25)
        Me.Perm.Name = "Perm"
        Me.Perm.Size = New System.Drawing.Size(36, 21)
        Me.Perm.TabIndex = 45
        Me.Perm.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'MinL
        '
        Me.MinL.BackColor = System.Drawing.Color.WhiteSmoke
        Me.MinL.Location = New System.Drawing.Point(113, 51)
        Me.MinL.Name = "MinL"
        Me.MinL.Size = New System.Drawing.Size(36, 21)
        Me.MinL.TabIndex = 46
        Me.MinL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'MaxL
        '
        Me.MaxL.BackColor = System.Drawing.Color.WhiteSmoke
        Me.MaxL.Location = New System.Drawing.Point(113, 78)
        Me.MaxL.Name = "MaxL"
        Me.MaxL.Size = New System.Drawing.Size(36, 21)
        Me.MaxL.TabIndex = 47
        Me.MaxL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBoxWord4
        '
        Me.GroupBoxWord4.Controls.Add(Me.tbWordStandard)
        Me.GroupBoxWord4.Location = New System.Drawing.Point(336, 426)
        Me.GroupBoxWord4.Name = "GroupBoxWord4"
        Me.GroupBoxWord4.Size = New System.Drawing.Size(322, 108)
        Me.GroupBoxWord4.TabIndex = 4
        Me.GroupBoxWord4.TabStop = False
        Me.GroupBoxWord4.Text = "Standard-Wordlist"
        '
        'tbWordStandard
        '
        Me.tbWordStandard.BackColor = System.Drawing.Color.Black
        Me.tbWordStandard.ForeColor = System.Drawing.Color.Lime
        Me.tbWordStandard.Location = New System.Drawing.Point(6, 19)
        Me.tbWordStandard.Multiline = True
        Me.tbWordStandard.Name = "tbWordStandard"
        Me.tbWordStandard.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tbWordStandard.Size = New System.Drawing.Size(300, 79)
        Me.tbWordStandard.TabIndex = 65
        '
        'GroupBoxWord2
        '
        Me.GroupBoxWord2.Controls.Add(Me.tbWord45)
        Me.GroupBoxWord2.Controls.Add(Me.tbWord40)
        Me.GroupBoxWord2.Controls.Add(Me.lbWordInfos)
        Me.GroupBoxWord2.Controls.Add(Me.tbWord36)
        Me.GroupBoxWord2.Controls.Add(Me.tbWord44)
        Me.GroupBoxWord2.Controls.Add(Me.tbWord37)
        Me.GroupBoxWord2.Controls.Add(Me.tbWord38)
        Me.GroupBoxWord2.Controls.Add(Me.tbWord43)
        Me.GroupBoxWord2.Controls.Add(Me.tbWord39)
        Me.GroupBoxWord2.Controls.Add(Me.tbWord42)
        Me.GroupBoxWord2.Controls.Add(Me.tbWord41)
        Me.GroupBoxWord2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxWord2.Location = New System.Drawing.Point(22, 308)
        Me.GroupBoxWord2.Name = "GroupBoxWord2"
        Me.GroupBoxWord2.Size = New System.Drawing.Size(636, 112)
        Me.GroupBoxWord2.TabIndex = 2
        Me.GroupBoxWord2.TabStop = False
        Me.GroupBoxWord2.Text = "Other Information"
        '
        'tbWord45
        '
        Me.tbWord45.BackColor = System.Drawing.Color.White
        Me.tbWord45.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord45.Location = New System.Drawing.Point(515, 80)
        Me.tbWord45.Name = "tbWord45"
        Me.tbWord45.Size = New System.Drawing.Size(100, 21)
        Me.tbWord45.TabIndex = 44
        '
        'tbWord40
        '
        Me.tbWord40.BackColor = System.Drawing.Color.White
        Me.tbWord40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord40.Location = New System.Drawing.Point(515, 54)
        Me.tbWord40.Name = "tbWord40"
        Me.tbWord40.Size = New System.Drawing.Size(100, 21)
        Me.tbWord40.TabIndex = 39
        '
        'lbWordInfos
        '
        Me.lbWordInfos.AutoSize = True
        Me.lbWordInfos.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbWordInfos.Location = New System.Drawing.Point(6, 28)
        Me.lbWordInfos.Name = "lbWordInfos"
        Me.lbWordInfos.Size = New System.Drawing.Size(347, 15)
        Me.lbWordInfos.TabIndex = 45
        Me.lbWordInfos.Text = "Other Information (e.g. Petname, Footballteam, Nicknames, ...)"
        '
        'tbWord36
        '
        Me.tbWord36.BackColor = System.Drawing.Color.White
        Me.tbWord36.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord36.Location = New System.Drawing.Point(91, 54)
        Me.tbWord36.Name = "tbWord36"
        Me.tbWord36.Size = New System.Drawing.Size(100, 21)
        Me.tbWord36.TabIndex = 35
        '
        'tbWord44
        '
        Me.tbWord44.BackColor = System.Drawing.Color.White
        Me.tbWord44.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord44.Location = New System.Drawing.Point(409, 80)
        Me.tbWord44.Name = "tbWord44"
        Me.tbWord44.Size = New System.Drawing.Size(100, 21)
        Me.tbWord44.TabIndex = 43
        '
        'tbWord37
        '
        Me.tbWord37.BackColor = System.Drawing.Color.White
        Me.tbWord37.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord37.Location = New System.Drawing.Point(197, 54)
        Me.tbWord37.Name = "tbWord37"
        Me.tbWord37.Size = New System.Drawing.Size(100, 21)
        Me.tbWord37.TabIndex = 36
        '
        'tbWord38
        '
        Me.tbWord38.BackColor = System.Drawing.Color.White
        Me.tbWord38.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord38.Location = New System.Drawing.Point(303, 54)
        Me.tbWord38.Name = "tbWord38"
        Me.tbWord38.Size = New System.Drawing.Size(100, 21)
        Me.tbWord38.TabIndex = 37
        '
        'tbWord43
        '
        Me.tbWord43.BackColor = System.Drawing.Color.White
        Me.tbWord43.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord43.Location = New System.Drawing.Point(303, 80)
        Me.tbWord43.Name = "tbWord43"
        Me.tbWord43.Size = New System.Drawing.Size(100, 21)
        Me.tbWord43.TabIndex = 42
        '
        'tbWord39
        '
        Me.tbWord39.BackColor = System.Drawing.Color.White
        Me.tbWord39.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord39.Location = New System.Drawing.Point(409, 54)
        Me.tbWord39.Name = "tbWord39"
        Me.tbWord39.Size = New System.Drawing.Size(100, 21)
        Me.tbWord39.TabIndex = 38
        '
        'tbWord42
        '
        Me.tbWord42.BackColor = System.Drawing.Color.White
        Me.tbWord42.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord42.Location = New System.Drawing.Point(197, 80)
        Me.tbWord42.Name = "tbWord42"
        Me.tbWord42.Size = New System.Drawing.Size(100, 21)
        Me.tbWord42.TabIndex = 41
        '
        'tbWord41
        '
        Me.tbWord41.BackColor = System.Drawing.Color.White
        Me.tbWord41.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord41.Location = New System.Drawing.Point(91, 80)
        Me.tbWord41.Name = "tbWord41"
        Me.tbWord41.Size = New System.Drawing.Size(100, 21)
        Me.tbWord41.TabIndex = 40
        '
        'GroupBoxWord1
        '
        Me.GroupBoxWord1.Controls.Add(Me.lbWord1)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord35)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord30)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord25)
        Me.GroupBoxWord1.Controls.Add(Me.lbWordBirthyear)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord20)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord34)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord29)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord24)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord19)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord14)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord9)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord4)
        Me.GroupBoxWord1.Controls.Add(Me.lbWordBirthday)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord15)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord33)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord28)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord23)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord18)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord13)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord8)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord3)
        Me.GroupBoxWord1.Controls.Add(Me.lbWordSurname)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord10)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord32)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord27)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord22)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord17)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord12)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord7)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord2)
        Me.GroupBoxWord1.Controls.Add(Me.lbWordName)
        Me.GroupBoxWord1.Controls.Add(Me.lbWordNickname)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord5)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord31)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord26)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord21)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord16)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord11)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord6)
        Me.GroupBoxWord1.Controls.Add(Me.lbWordFather)
        Me.GroupBoxWord1.Controls.Add(Me.lbWordMother)
        Me.GroupBoxWord1.Controls.Add(Me.lbWordChild3)
        Me.GroupBoxWord1.Controls.Add(Me.lbWordChild2)
        Me.GroupBoxWord1.Controls.Add(Me.lbWordChild1)
        Me.GroupBoxWord1.Controls.Add(Me.lbWordWife)
        Me.GroupBoxWord1.Controls.Add(Me.lbWordTarget)
        Me.GroupBoxWord1.Controls.Add(Me.tbWord1)
        Me.GroupBoxWord1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxWord1.Location = New System.Drawing.Point(22, 18)
        Me.GroupBoxWord1.Name = "GroupBoxWord1"
        Me.GroupBoxWord1.Size = New System.Drawing.Size(636, 284)
        Me.GroupBoxWord1.TabIndex = 1
        Me.GroupBoxWord1.TabStop = False
        Me.GroupBoxWord1.Text = "Personal Information"
        '
        'lbWord1
        '
        Me.lbWord1.AutoSize = True
        Me.lbWord1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbWord1.Location = New System.Drawing.Point(6, 29)
        Me.lbWord1.Name = "lbWord1"
        Me.lbWord1.Size = New System.Drawing.Size(529, 15)
        Me.lbWord1.TabIndex = 47
        Me.lbWord1.Text = "Please enter all entries in lowercase letters. Enter the date of birth without po" &
    "ints."
        '
        'tbWord35
        '
        Me.tbWord35.BackColor = System.Drawing.Color.White
        Me.tbWord35.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord35.Location = New System.Drawing.Point(520, 250)
        Me.tbWord35.Name = "tbWord35"
        Me.tbWord35.Size = New System.Drawing.Size(100, 21)
        Me.tbWord35.TabIndex = 34
        '
        'tbWord30
        '
        Me.tbWord30.BackColor = System.Drawing.Color.White
        Me.tbWord30.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord30.Location = New System.Drawing.Point(520, 223)
        Me.tbWord30.Name = "tbWord30"
        Me.tbWord30.Size = New System.Drawing.Size(100, 21)
        Me.tbWord30.TabIndex = 29
        '
        'tbWord25
        '
        Me.tbWord25.BackColor = System.Drawing.Color.White
        Me.tbWord25.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord25.Location = New System.Drawing.Point(520, 196)
        Me.tbWord25.Name = "tbWord25"
        Me.tbWord25.Size = New System.Drawing.Size(100, 21)
        Me.tbWord25.TabIndex = 24
        '
        'lbWordBirthyear
        '
        Me.lbWordBirthyear.AutoSize = True
        Me.lbWordBirthyear.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbWordBirthyear.Location = New System.Drawing.Point(420, 63)
        Me.lbWordBirthyear.Name = "lbWordBirthyear"
        Me.lbWordBirthyear.Size = New System.Drawing.Size(94, 15)
        Me.lbWordBirthyear.TabIndex = 43
        Me.lbWordBirthyear.Text = "Birthyear (YYYY)"
        '
        'tbWord20
        '
        Me.tbWord20.BackColor = System.Drawing.Color.White
        Me.tbWord20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord20.Location = New System.Drawing.Point(520, 168)
        Me.tbWord20.Name = "tbWord20"
        Me.tbWord20.Size = New System.Drawing.Size(100, 21)
        Me.tbWord20.TabIndex = 19
        '
        'tbWord34
        '
        Me.tbWord34.BackColor = System.Drawing.Color.White
        Me.tbWord34.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord34.Location = New System.Drawing.Point(414, 250)
        Me.tbWord34.Name = "tbWord34"
        Me.tbWord34.Size = New System.Drawing.Size(100, 21)
        Me.tbWord34.TabIndex = 33
        '
        'tbWord29
        '
        Me.tbWord29.BackColor = System.Drawing.Color.White
        Me.tbWord29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord29.Location = New System.Drawing.Point(414, 223)
        Me.tbWord29.Name = "tbWord29"
        Me.tbWord29.Size = New System.Drawing.Size(100, 21)
        Me.tbWord29.TabIndex = 28
        '
        'tbWord24
        '
        Me.tbWord24.BackColor = System.Drawing.Color.White
        Me.tbWord24.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord24.Location = New System.Drawing.Point(414, 196)
        Me.tbWord24.Name = "tbWord24"
        Me.tbWord24.Size = New System.Drawing.Size(100, 21)
        Me.tbWord24.TabIndex = 23
        '
        'tbWord19
        '
        Me.tbWord19.BackColor = System.Drawing.Color.White
        Me.tbWord19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord19.Location = New System.Drawing.Point(414, 168)
        Me.tbWord19.Name = "tbWord19"
        Me.tbWord19.Size = New System.Drawing.Size(100, 21)
        Me.tbWord19.TabIndex = 18
        '
        'tbWord14
        '
        Me.tbWord14.BackColor = System.Drawing.Color.White
        Me.tbWord14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord14.Location = New System.Drawing.Point(414, 138)
        Me.tbWord14.Name = "tbWord14"
        Me.tbWord14.Size = New System.Drawing.Size(100, 21)
        Me.tbWord14.TabIndex = 13
        '
        'tbWord9
        '
        Me.tbWord9.BackColor = System.Drawing.Color.White
        Me.tbWord9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord9.Location = New System.Drawing.Point(414, 109)
        Me.tbWord9.Name = "tbWord9"
        Me.tbWord9.Size = New System.Drawing.Size(100, 21)
        Me.tbWord9.TabIndex = 8
        '
        'tbWord4
        '
        Me.tbWord4.BackColor = System.Drawing.Color.White
        Me.tbWord4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord4.Location = New System.Drawing.Point(414, 79)
        Me.tbWord4.Name = "tbWord4"
        Me.tbWord4.Size = New System.Drawing.Size(100, 21)
        Me.tbWord4.TabIndex = 3
        '
        'lbWordBirthday
        '
        Me.lbWordBirthday.AutoSize = True
        Me.lbWordBirthday.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbWordBirthday.Location = New System.Drawing.Point(305, 63)
        Me.lbWordBirthday.Name = "lbWordBirthday"
        Me.lbWordBirthday.Size = New System.Drawing.Size(102, 15)
        Me.lbWordBirthday.TabIndex = 34
        Me.lbWordBirthday.Text = "Birthday (DDMM)"
        '
        'tbWord15
        '
        Me.tbWord15.BackColor = System.Drawing.Color.White
        Me.tbWord15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord15.Location = New System.Drawing.Point(520, 138)
        Me.tbWord15.Name = "tbWord15"
        Me.tbWord15.Size = New System.Drawing.Size(100, 21)
        Me.tbWord15.TabIndex = 14
        '
        'tbWord33
        '
        Me.tbWord33.BackColor = System.Drawing.Color.White
        Me.tbWord33.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord33.Location = New System.Drawing.Point(308, 250)
        Me.tbWord33.Name = "tbWord33"
        Me.tbWord33.Size = New System.Drawing.Size(100, 21)
        Me.tbWord33.TabIndex = 32
        '
        'tbWord28
        '
        Me.tbWord28.BackColor = System.Drawing.Color.White
        Me.tbWord28.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord28.Location = New System.Drawing.Point(308, 223)
        Me.tbWord28.Name = "tbWord28"
        Me.tbWord28.Size = New System.Drawing.Size(100, 21)
        Me.tbWord28.TabIndex = 27
        '
        'tbWord23
        '
        Me.tbWord23.BackColor = System.Drawing.Color.White
        Me.tbWord23.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord23.Location = New System.Drawing.Point(308, 196)
        Me.tbWord23.Name = "tbWord23"
        Me.tbWord23.Size = New System.Drawing.Size(100, 21)
        Me.tbWord23.TabIndex = 22
        '
        'tbWord18
        '
        Me.tbWord18.BackColor = System.Drawing.Color.White
        Me.tbWord18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord18.Location = New System.Drawing.Point(308, 168)
        Me.tbWord18.Name = "tbWord18"
        Me.tbWord18.Size = New System.Drawing.Size(100, 21)
        Me.tbWord18.TabIndex = 17
        '
        'tbWord13
        '
        Me.tbWord13.BackColor = System.Drawing.Color.White
        Me.tbWord13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord13.Location = New System.Drawing.Point(308, 138)
        Me.tbWord13.Name = "tbWord13"
        Me.tbWord13.Size = New System.Drawing.Size(100, 21)
        Me.tbWord13.TabIndex = 12
        '
        'tbWord8
        '
        Me.tbWord8.BackColor = System.Drawing.Color.White
        Me.tbWord8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord8.Location = New System.Drawing.Point(308, 109)
        Me.tbWord8.Name = "tbWord8"
        Me.tbWord8.Size = New System.Drawing.Size(100, 21)
        Me.tbWord8.TabIndex = 7
        '
        'tbWord3
        '
        Me.tbWord3.BackColor = System.Drawing.Color.White
        Me.tbWord3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord3.Location = New System.Drawing.Point(308, 79)
        Me.tbWord3.Name = "tbWord3"
        Me.tbWord3.Size = New System.Drawing.Size(100, 21)
        Me.tbWord3.TabIndex = 2
        '
        'lbWordSurname
        '
        Me.lbWordSurname.AutoSize = True
        Me.lbWordSurname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbWordSurname.Location = New System.Drawing.Point(219, 63)
        Me.lbWordSurname.Name = "lbWordSurname"
        Me.lbWordSurname.Size = New System.Drawing.Size(58, 15)
        Me.lbWordSurname.TabIndex = 25
        Me.lbWordSurname.Text = "Surname"
        '
        'tbWord10
        '
        Me.tbWord10.BackColor = System.Drawing.Color.White
        Me.tbWord10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord10.Location = New System.Drawing.Point(520, 109)
        Me.tbWord10.Name = "tbWord10"
        Me.tbWord10.Size = New System.Drawing.Size(100, 21)
        Me.tbWord10.TabIndex = 9
        '
        'tbWord32
        '
        Me.tbWord32.BackColor = System.Drawing.Color.White
        Me.tbWord32.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord32.Location = New System.Drawing.Point(202, 250)
        Me.tbWord32.Name = "tbWord32"
        Me.tbWord32.Size = New System.Drawing.Size(100, 21)
        Me.tbWord32.TabIndex = 31
        '
        'tbWord27
        '
        Me.tbWord27.BackColor = System.Drawing.Color.White
        Me.tbWord27.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord27.Location = New System.Drawing.Point(202, 223)
        Me.tbWord27.Name = "tbWord27"
        Me.tbWord27.Size = New System.Drawing.Size(100, 21)
        Me.tbWord27.TabIndex = 26
        '
        'tbWord22
        '
        Me.tbWord22.BackColor = System.Drawing.Color.White
        Me.tbWord22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord22.Location = New System.Drawing.Point(202, 196)
        Me.tbWord22.Name = "tbWord22"
        Me.tbWord22.Size = New System.Drawing.Size(100, 21)
        Me.tbWord22.TabIndex = 21
        '
        'tbWord17
        '
        Me.tbWord17.BackColor = System.Drawing.Color.White
        Me.tbWord17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord17.Location = New System.Drawing.Point(202, 168)
        Me.tbWord17.Name = "tbWord17"
        Me.tbWord17.Size = New System.Drawing.Size(100, 21)
        Me.tbWord17.TabIndex = 16
        '
        'tbWord12
        '
        Me.tbWord12.BackColor = System.Drawing.Color.White
        Me.tbWord12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord12.Location = New System.Drawing.Point(202, 138)
        Me.tbWord12.Name = "tbWord12"
        Me.tbWord12.Size = New System.Drawing.Size(100, 21)
        Me.tbWord12.TabIndex = 11
        '
        'tbWord7
        '
        Me.tbWord7.BackColor = System.Drawing.Color.White
        Me.tbWord7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord7.Location = New System.Drawing.Point(202, 109)
        Me.tbWord7.Name = "tbWord7"
        Me.tbWord7.Size = New System.Drawing.Size(100, 21)
        Me.tbWord7.TabIndex = 6
        '
        'tbWord2
        '
        Me.tbWord2.BackColor = System.Drawing.Color.White
        Me.tbWord2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord2.Location = New System.Drawing.Point(202, 79)
        Me.tbWord2.Name = "tbWord2"
        Me.tbWord2.Size = New System.Drawing.Size(100, 21)
        Me.tbWord2.TabIndex = 1
        '
        'lbWordName
        '
        Me.lbWordName.AutoSize = True
        Me.lbWordName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbWordName.Location = New System.Drawing.Point(110, 63)
        Me.lbWordName.Name = "lbWordName"
        Me.lbWordName.Size = New System.Drawing.Size(67, 15)
        Me.lbWordName.TabIndex = 16
        Me.lbWordName.Text = "First Name"
        '
        'lbWordNickname
        '
        Me.lbWordNickname.AutoSize = True
        Me.lbWordNickname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbWordNickname.Location = New System.Drawing.Point(539, 63)
        Me.lbWordNickname.Name = "lbWordNickname"
        Me.lbWordNickname.Size = New System.Drawing.Size(63, 15)
        Me.lbWordNickname.TabIndex = 15
        Me.lbWordNickname.Text = "Nickname"
        '
        'tbWord5
        '
        Me.tbWord5.BackColor = System.Drawing.Color.White
        Me.tbWord5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord5.Location = New System.Drawing.Point(520, 79)
        Me.tbWord5.Name = "tbWord5"
        Me.tbWord5.Size = New System.Drawing.Size(100, 21)
        Me.tbWord5.TabIndex = 4
        '
        'tbWord31
        '
        Me.tbWord31.BackColor = System.Drawing.Color.White
        Me.tbWord31.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord31.Location = New System.Drawing.Point(96, 250)
        Me.tbWord31.Name = "tbWord31"
        Me.tbWord31.Size = New System.Drawing.Size(100, 21)
        Me.tbWord31.TabIndex = 30
        '
        'tbWord26
        '
        Me.tbWord26.BackColor = System.Drawing.Color.White
        Me.tbWord26.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord26.Location = New System.Drawing.Point(96, 223)
        Me.tbWord26.Name = "tbWord26"
        Me.tbWord26.Size = New System.Drawing.Size(100, 21)
        Me.tbWord26.TabIndex = 25
        '
        'tbWord21
        '
        Me.tbWord21.BackColor = System.Drawing.Color.White
        Me.tbWord21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord21.Location = New System.Drawing.Point(96, 196)
        Me.tbWord21.Name = "tbWord21"
        Me.tbWord21.Size = New System.Drawing.Size(100, 21)
        Me.tbWord21.TabIndex = 20
        '
        'tbWord16
        '
        Me.tbWord16.BackColor = System.Drawing.Color.White
        Me.tbWord16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord16.Location = New System.Drawing.Point(96, 168)
        Me.tbWord16.Name = "tbWord16"
        Me.tbWord16.Size = New System.Drawing.Size(100, 21)
        Me.tbWord16.TabIndex = 15
        '
        'tbWord11
        '
        Me.tbWord11.BackColor = System.Drawing.Color.White
        Me.tbWord11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord11.Location = New System.Drawing.Point(96, 138)
        Me.tbWord11.Name = "tbWord11"
        Me.tbWord11.Size = New System.Drawing.Size(100, 21)
        Me.tbWord11.TabIndex = 10
        '
        'tbWord6
        '
        Me.tbWord6.BackColor = System.Drawing.Color.White
        Me.tbWord6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord6.Location = New System.Drawing.Point(96, 109)
        Me.tbWord6.Name = "tbWord6"
        Me.tbWord6.Size = New System.Drawing.Size(100, 21)
        Me.tbWord6.TabIndex = 5
        '
        'lbWordFather
        '
        Me.lbWordFather.AutoSize = True
        Me.lbWordFather.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbWordFather.Location = New System.Drawing.Point(6, 250)
        Me.lbWordFather.Name = "lbWordFather"
        Me.lbWordFather.Size = New System.Drawing.Size(42, 15)
        Me.lbWordFather.TabIndex = 7
        Me.lbWordFather.Text = "Father"
        '
        'lbWordMother
        '
        Me.lbWordMother.AutoSize = True
        Me.lbWordMother.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbWordMother.Location = New System.Drawing.Point(6, 223)
        Me.lbWordMother.Name = "lbWordMother"
        Me.lbWordMother.Size = New System.Drawing.Size(46, 15)
        Me.lbWordMother.TabIndex = 6
        Me.lbWordMother.Text = "Mother"
        '
        'lbWordChild3
        '
        Me.lbWordChild3.AutoSize = True
        Me.lbWordChild3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbWordChild3.Location = New System.Drawing.Point(6, 193)
        Me.lbWordChild3.Name = "lbWordChild3"
        Me.lbWordChild3.Size = New System.Drawing.Size(45, 15)
        Me.lbWordChild3.TabIndex = 5
        Me.lbWordChild3.Text = "Child 3"
        '
        'lbWordChild2
        '
        Me.lbWordChild2.AutoSize = True
        Me.lbWordChild2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbWordChild2.Location = New System.Drawing.Point(6, 165)
        Me.lbWordChild2.Name = "lbWordChild2"
        Me.lbWordChild2.Size = New System.Drawing.Size(45, 15)
        Me.lbWordChild2.TabIndex = 4
        Me.lbWordChild2.Text = "Child 2"
        '
        'lbWordChild1
        '
        Me.lbWordChild1.AutoSize = True
        Me.lbWordChild1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbWordChild1.Location = New System.Drawing.Point(6, 138)
        Me.lbWordChild1.Name = "lbWordChild1"
        Me.lbWordChild1.Size = New System.Drawing.Size(45, 15)
        Me.lbWordChild1.TabIndex = 3
        Me.lbWordChild1.Text = "Child 1"
        '
        'lbWordWife
        '
        Me.lbWordWife.AutoSize = True
        Me.lbWordWife.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbWordWife.Location = New System.Drawing.Point(6, 112)
        Me.lbWordWife.Name = "lbWordWife"
        Me.lbWordWife.Size = New System.Drawing.Size(90, 15)
        Me.lbWordWife.TabIndex = 2
        Me.lbWordWife.Text = "Wife / Husband"
        '
        'lbWordTarget
        '
        Me.lbWordTarget.AutoSize = True
        Me.lbWordTarget.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbWordTarget.Location = New System.Drawing.Point(6, 82)
        Me.lbWordTarget.Name = "lbWordTarget"
        Me.lbWordTarget.Size = New System.Drawing.Size(48, 15)
        Me.lbWordTarget.TabIndex = 1
        Me.lbWordTarget.Text = "Subject"
        '
        'tbWord1
        '
        Me.tbWord1.BackColor = System.Drawing.Color.White
        Me.tbWord1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWord1.Location = New System.Drawing.Point(96, 79)
        Me.tbWord1.Name = "tbWord1"
        Me.tbWord1.Size = New System.Drawing.Size(100, 21)
        Me.tbWord1.TabIndex = 0
        '
        'btnWordOpen
        '
        Me.btnWordOpen.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnWordOpen.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.btnWordOpen.Location = New System.Drawing.Point(668, 468)
        Me.btnWordOpen.Name = "btnWordOpen"
        Me.btnWordOpen.Size = New System.Drawing.Size(76, 27)
        Me.btnWordOpen.TabIndex = 64
        Me.btnWordOpen.Text = "Open File"
        Me.btnWordOpen.UseVisualStyleBackColor = False
        '
        'btnWordStart
        '
        Me.btnWordStart.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnWordStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWordStart.Location = New System.Drawing.Point(668, 504)
        Me.btnWordStart.Name = "btnWordStart"
        Me.btnWordStart.Size = New System.Drawing.Size(76, 27)
        Me.btnWordStart.TabIndex = 63
        Me.btnWordStart.Text = "START"
        Me.btnWordStart.UseVisualStyleBackColor = False
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.GroupBoxcewl2)
        Me.TabPage5.Controls.Add(Me.btnCewlStart)
        Me.TabPage5.Controls.Add(Me.GroupBoxCewl1)
        Me.TabPage5.Controls.Add(Me.GroupBoxcewl3)
        Me.TabPage5.Location = New System.Drawing.Point(4, 24)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(794, 552)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "CeWL"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'GroupBoxcewl2
        '
        Me.GroupBoxcewl2.Controls.Add(Me.lbcewl3)
        Me.GroupBoxcewl2.Controls.Add(Me.tbCewlPage)
        Me.GroupBoxcewl2.Controls.Add(Me.lbcewl2)
        Me.GroupBoxcewl2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxcewl2.Location = New System.Drawing.Point(22, 224)
        Me.GroupBoxcewl2.Name = "GroupBoxcewl2"
        Me.GroupBoxcewl2.Size = New System.Drawing.Size(673, 111)
        Me.GroupBoxcewl2.TabIndex = 28
        Me.GroupBoxcewl2.TabStop = False
        Me.GroupBoxcewl2.Text = "CeWL"
        '
        'lbcewl3
        '
        Me.lbcewl3.AutoSize = True
        Me.lbcewl3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbcewl3.Location = New System.Drawing.Point(6, 73)
        Me.lbcewl3.Name = "lbcewl3"
        Me.lbcewl3.Size = New System.Drawing.Size(123, 16)
        Me.lbcewl3.TabIndex = 3
        Me.lbcewl3.Text = "Target Homepage:"
        '
        'tbCewlPage
        '
        Me.tbCewlPage.BackColor = System.Drawing.Color.White
        Me.tbCewlPage.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbCewlPage.Location = New System.Drawing.Point(229, 72)
        Me.tbCewlPage.Name = "tbCewlPage"
        Me.tbCewlPage.Size = New System.Drawing.Size(421, 22)
        Me.tbCewlPage.TabIndex = 0
        '
        'lbcewl2
        '
        Me.lbcewl2.AutoSize = True
        Me.lbcewl2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbcewl2.Location = New System.Drawing.Point(6, 28)
        Me.lbcewl2.Name = "lbcewl2"
        Me.lbcewl2.Size = New System.Drawing.Size(634, 32)
        Me.lbcewl2.TabIndex = 0
        Me.lbcewl2.Text = "CeWL spiders a given URL to a specified depth and returns wordlists and Email-Add" &
    "ress. Please note the " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "spelling: http(s)://. The extraction is saved in the fol" &
    "der ""#_Wordlists""."
        '
        'btnCewlStart
        '
        Me.btnCewlStart.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnCewlStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCewlStart.ForeColor = System.Drawing.SystemColors.InfoText
        Me.btnCewlStart.Location = New System.Drawing.Point(600, 341)
        Me.btnCewlStart.Name = "btnCewlStart"
        Me.btnCewlStart.Size = New System.Drawing.Size(95, 30)
        Me.btnCewlStart.TabIndex = 16
        Me.btnCewlStart.Text = "START"
        Me.btnCewlStart.UseVisualStyleBackColor = False
        '
        'GroupBoxCewl1
        '
        Me.GroupBoxCewl1.Controls.Add(Me.lbCewlInstall)
        Me.GroupBoxCewl1.Controls.Add(Me.lbCewl1)
        Me.GroupBoxCewl1.Controls.Add(Me.btnCewlInstall)
        Me.GroupBoxCewl1.Controls.Add(Me.btnCewlLinux)
        Me.GroupBoxCewl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxCewl1.Location = New System.Drawing.Point(22, 24)
        Me.GroupBoxCewl1.Name = "GroupBoxCewl1"
        Me.GroupBoxCewl1.Size = New System.Drawing.Size(353, 185)
        Me.GroupBoxCewl1.TabIndex = 31
        Me.GroupBoxCewl1.TabStop = False
        Me.GroupBoxCewl1.Text = "First Steps"
        '
        'lbCewlInstall
        '
        Me.lbCewlInstall.AutoSize = True
        Me.lbCewlInstall.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbCewlInstall.Location = New System.Drawing.Point(6, 115)
        Me.lbCewlInstall.Name = "lbCewlInstall"
        Me.lbCewlInstall.Size = New System.Drawing.Size(335, 16)
        Me.lbCewlInstall.TabIndex = 13
        Me.lbCewlInstall.Text = "2) Now CeWL can be installed. Please press the button:"
        '
        'lbCewl1
        '
        Me.lbCewl1.AutoSize = True
        Me.lbCewl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbCewl1.Location = New System.Drawing.Point(6, 27)
        Me.lbCewl1.Name = "lbCewl1"
        Me.lbCewl1.Size = New System.Drawing.Size(336, 48)
        Me.lbCewl1.TabIndex = 14
        Me.lbCewl1.Text = "1) When using CeWL for the first time, you have to install" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Linux for Windows (Ub" &
    "untu 20.04. LTS). Press the button " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "for further steps:"
        '
        'btnCewlInstall
        '
        Me.btnCewlInstall.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnCewlInstall.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCewlInstall.Location = New System.Drawing.Point(6, 134)
        Me.btnCewlInstall.Name = "btnCewlInstall"
        Me.btnCewlInstall.Size = New System.Drawing.Size(118, 23)
        Me.btnCewlInstall.TabIndex = 14
        Me.btnCewlInstall.Text = "Install CeWL"
        Me.btnCewlInstall.UseVisualStyleBackColor = False
        '
        'btnCewlLinux
        '
        Me.btnCewlLinux.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCewlLinux.Location = New System.Drawing.Point(6, 78)
        Me.btnCewlLinux.Name = "btnCewlLinux"
        Me.btnCewlLinux.Size = New System.Drawing.Size(118, 23)
        Me.btnCewlLinux.TabIndex = 13
        Me.btnCewlLinux.Text = "Install Linux"
        Me.btnCewlLinux.UseVisualStyleBackColor = True
        '
        'GroupBoxcewl3
        '
        Me.GroupBoxcewl3.Controls.Add(Me.lbcewl4)
        Me.GroupBoxcewl3.Controls.Add(Me.lbcewl5)
        Me.GroupBoxcewl3.Controls.Add(Me.tbCewlWord)
        Me.GroupBoxcewl3.Controls.Add(Me.tbCewlSpider)
        Me.GroupBoxcewl3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxcewl3.Location = New System.Drawing.Point(393, 24)
        Me.GroupBoxcewl3.Name = "GroupBoxcewl3"
        Me.GroupBoxcewl3.Size = New System.Drawing.Size(302, 185)
        Me.GroupBoxcewl3.TabIndex = 29
        Me.GroupBoxcewl3.TabStop = False
        Me.GroupBoxcewl3.Text = "Settings (optional)"
        '
        'lbcewl4
        '
        Me.lbcewl4.AutoSize = True
        Me.lbcewl4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbcewl4.Location = New System.Drawing.Point(6, 28)
        Me.lbcewl4.Name = "lbcewl4"
        Me.lbcewl4.Size = New System.Drawing.Size(194, 16)
        Me.lbcewl4.TabIndex = 10
        Me.lbcewl4.Text = "Max. Depth to spider (default: 2)"
        '
        'lbcewl5
        '
        Me.lbcewl5.AutoSize = True
        Me.lbcewl5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbcewl5.Location = New System.Drawing.Point(6, 56)
        Me.lbcewl5.Name = "lbcewl5"
        Me.lbcewl5.Size = New System.Drawing.Size(171, 16)
        Me.lbcewl5.TabIndex = 4
        Me.lbcewl5.Text = "Min. Word-Length (optional)"
        '
        'tbCewlWord
        '
        Me.tbCewlWord.BackColor = System.Drawing.Color.White
        Me.tbCewlWord.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbCewlWord.Location = New System.Drawing.Point(229, 55)
        Me.tbCewlWord.Name = "tbCewlWord"
        Me.tbCewlWord.Size = New System.Drawing.Size(50, 22)
        Me.tbCewlWord.TabIndex = 2
        Me.tbCewlWord.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbCewlSpider
        '
        Me.tbCewlSpider.BackColor = System.Drawing.Color.White
        Me.tbCewlSpider.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbCewlSpider.Location = New System.Drawing.Point(229, 27)
        Me.tbCewlSpider.Name = "tbCewlSpider"
        Me.tbCewlSpider.Size = New System.Drawing.Size(50, 22)
        Me.tbCewlSpider.TabIndex = 1
        Me.tbCewlSpider.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.GroupBoxComb2)
        Me.TabPage6.Controls.Add(Me.GroupBoxComb1)
        Me.TabPage6.Location = New System.Drawing.Point(4, 24)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(794, 552)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Combinator/Len"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'GroupBoxComb2
        '
        Me.GroupBoxComb2.Controls.Add(Me.pbLen)
        Me.GroupBoxComb2.Controls.Add(Me.lbLen4)
        Me.GroupBoxComb2.Controls.Add(Me.LenMaxTxb)
        Me.GroupBoxComb2.Controls.Add(Me.btnLen)
        Me.GroupBoxComb2.Controls.Add(Me.lbLen3)
        Me.GroupBoxComb2.Controls.Add(Me.lbLen2)
        Me.GroupBoxComb2.Controls.Add(Me.LenMinTxb)
        Me.GroupBoxComb2.Controls.Add(Me.lbLen1)
        Me.GroupBoxComb2.Controls.Add(Me.LenTxb)
        Me.GroupBoxComb2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxComb2.Location = New System.Drawing.Point(20, 271)
        Me.GroupBoxComb2.Name = "GroupBoxComb2"
        Me.GroupBoxComb2.Size = New System.Drawing.Size(579, 166)
        Me.GroupBoxComb2.TabIndex = 7
        Me.GroupBoxComb2.TabStop = False
        Me.GroupBoxComb2.Text = "Len"
        '
        'pbLen
        '
        Me.pbLen.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pbLen.Image = CType(resources.GetObject("pbLen.Image"), System.Drawing.Image)
        Me.pbLen.Location = New System.Drawing.Point(480, 98)
        Me.pbLen.Name = "pbLen"
        Me.pbLen.Size = New System.Drawing.Size(25, 21)
        Me.pbLen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbLen.TabIndex = 31
        Me.pbLen.TabStop = False
        '
        'lbLen4
        '
        Me.lbLen4.AutoSize = True
        Me.lbLen4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbLen4.Location = New System.Drawing.Point(217, 129)
        Me.lbLen4.Name = "lbLen4"
        Me.lbLen4.Size = New System.Drawing.Size(31, 16)
        Me.lbLen4.TabIndex = 7
        Me.lbLen4.Text = "until"
        '
        'LenMaxTxb
        '
        Me.LenMaxTxb.BackColor = System.Drawing.Color.White
        Me.LenMaxTxb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LenMaxTxb.Location = New System.Drawing.Point(254, 126)
        Me.LenMaxTxb.Name = "LenMaxTxb"
        Me.LenMaxTxb.Size = New System.Drawing.Size(85, 22)
        Me.LenMaxTxb.TabIndex = 2
        Me.LenMaxTxb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnLen
        '
        Me.btnLen.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnLen.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLen.Location = New System.Drawing.Point(399, 126)
        Me.btnLen.Name = "btnLen"
        Me.btnLen.Size = New System.Drawing.Size(75, 22)
        Me.btnLen.TabIndex = 10
        Me.btnLen.Text = "START"
        Me.btnLen.UseVisualStyleBackColor = False
        '
        'lbLen3
        '
        Me.lbLen3.AutoSize = True
        Me.lbLen3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbLen3.Location = New System.Drawing.Point(6, 129)
        Me.lbLen3.Name = "lbLen3"
        Me.lbLen3.Size = New System.Drawing.Size(88, 16)
        Me.lbLen3.TabIndex = 3
        Me.lbLen3.Text = "Word-Length:"
        '
        'lbLen2
        '
        Me.lbLen2.AutoSize = True
        Me.lbLen2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbLen2.Location = New System.Drawing.Point(6, 101)
        Me.lbLen2.Name = "lbLen2"
        Me.lbLen2.Size = New System.Drawing.Size(60, 16)
        Me.lbLen2.TabIndex = 2
        Me.lbLen2.Text = "Wordlist:"
        '
        'LenMinTxb
        '
        Me.LenMinTxb.BackColor = System.Drawing.Color.White
        Me.LenMinTxb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LenMinTxb.Location = New System.Drawing.Point(99, 126)
        Me.LenMinTxb.Name = "LenMinTxb"
        Me.LenMinTxb.Size = New System.Drawing.Size(105, 22)
        Me.LenMinTxb.TabIndex = 1
        Me.LenMinTxb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbLen1
        '
        Me.lbLen1.AutoSize = True
        Me.lbLen1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbLen1.Location = New System.Drawing.Point(6, 28)
        Me.lbLen1.Name = "lbLen1"
        Me.lbLen1.Size = New System.Drawing.Size(499, 48)
        Me.lbLen1.TabIndex = 1
        Me.lbLen1.Text = "With ""Len"" you can extract password candidates with a certain length from Wordlis" &
    "ts" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "into a new Wordlist. For example, you could extract all passwords with a min" &
    "imum " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "length of 8 from a wordlist."
        '
        'LenTxb
        '
        Me.LenTxb.BackColor = System.Drawing.Color.White
        Me.LenTxb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LenTxb.Location = New System.Drawing.Point(99, 98)
        Me.LenTxb.Name = "LenTxb"
        Me.LenTxb.Size = New System.Drawing.Size(375, 22)
        Me.LenTxb.TabIndex = 0
        '
        'GroupBoxComb1
        '
        Me.GroupBoxComb1.Controls.Add(Me.pbCombinator3)
        Me.GroupBoxComb1.Controls.Add(Me.pbCombinator2)
        Me.GroupBoxComb1.Controls.Add(Me.pbCombinator1)
        Me.GroupBoxComb1.Controls.Add(Me.lbComb4)
        Me.GroupBoxComb1.Controls.Add(Me.File3Txb)
        Me.GroupBoxComb1.Controls.Add(Me.btnCombinator)
        Me.GroupBoxComb1.Controls.Add(Me.lbComb3)
        Me.GroupBoxComb1.Controls.Add(Me.lbComb2)
        Me.GroupBoxComb1.Controls.Add(Me.File2Txb)
        Me.GroupBoxComb1.Controls.Add(Me.lbComb1)
        Me.GroupBoxComb1.Controls.Add(Me.File1Txb)
        Me.GroupBoxComb1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxComb1.Location = New System.Drawing.Point(20, 24)
        Me.GroupBoxComb1.Name = "GroupBoxComb1"
        Me.GroupBoxComb1.Size = New System.Drawing.Size(579, 232)
        Me.GroupBoxComb1.TabIndex = 5
        Me.GroupBoxComb1.TabStop = False
        Me.GroupBoxComb1.Text = "Combinator"
        '
        'pbCombinator3
        '
        Me.pbCombinator3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pbCombinator3.Image = CType(resources.GetObject("pbCombinator3.Image"), System.Drawing.Image)
        Me.pbCombinator3.Location = New System.Drawing.Point(480, 164)
        Me.pbCombinator3.Name = "pbCombinator3"
        Me.pbCombinator3.Size = New System.Drawing.Size(25, 21)
        Me.pbCombinator3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbCombinator3.TabIndex = 32
        Me.pbCombinator3.TabStop = False
        '
        'pbCombinator2
        '
        Me.pbCombinator2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pbCombinator2.Image = CType(resources.GetObject("pbCombinator2.Image"), System.Drawing.Image)
        Me.pbCombinator2.Location = New System.Drawing.Point(480, 136)
        Me.pbCombinator2.Name = "pbCombinator2"
        Me.pbCombinator2.Size = New System.Drawing.Size(25, 21)
        Me.pbCombinator2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbCombinator2.TabIndex = 31
        Me.pbCombinator2.TabStop = False
        '
        'pbCombinator1
        '
        Me.pbCombinator1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pbCombinator1.Image = CType(resources.GetObject("pbCombinator1.Image"), System.Drawing.Image)
        Me.pbCombinator1.Location = New System.Drawing.Point(480, 108)
        Me.pbCombinator1.Name = "pbCombinator1"
        Me.pbCombinator1.Size = New System.Drawing.Size(25, 21)
        Me.pbCombinator1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbCombinator1.TabIndex = 30
        Me.pbCombinator1.TabStop = False
        '
        'lbComb4
        '
        Me.lbComb4.AutoSize = True
        Me.lbComb4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbComb4.Location = New System.Drawing.Point(6, 167)
        Me.lbComb4.Name = "lbComb4"
        Me.lbComb4.Size = New System.Drawing.Size(43, 16)
        Me.lbComb4.TabIndex = 7
        Me.lbComb4.Text = "File 3:"
        '
        'File3Txb
        '
        Me.File3Txb.BackColor = System.Drawing.Color.White
        Me.File3Txb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.File3Txb.Location = New System.Drawing.Point(99, 164)
        Me.File3Txb.Name = "File3Txb"
        Me.File3Txb.Size = New System.Drawing.Size(375, 22)
        Me.File3Txb.TabIndex = 5
        Me.File3Txb.TabStop = False
        '
        'btnCombinator
        '
        Me.btnCombinator.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnCombinator.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCombinator.Location = New System.Drawing.Point(399, 192)
        Me.btnCombinator.Name = "btnCombinator"
        Me.btnCombinator.Size = New System.Drawing.Size(75, 23)
        Me.btnCombinator.TabIndex = 3
        Me.btnCombinator.Text = "START"
        Me.btnCombinator.UseVisualStyleBackColor = False
        '
        'lbComb3
        '
        Me.lbComb3.AutoSize = True
        Me.lbComb3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbComb3.Location = New System.Drawing.Point(6, 139)
        Me.lbComb3.Name = "lbComb3"
        Me.lbComb3.Size = New System.Drawing.Size(43, 16)
        Me.lbComb3.TabIndex = 3
        Me.lbComb3.Text = "File 2:"
        '
        'lbComb2
        '
        Me.lbComb2.AutoSize = True
        Me.lbComb2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbComb2.Location = New System.Drawing.Point(6, 111)
        Me.lbComb2.Name = "lbComb2"
        Me.lbComb2.Size = New System.Drawing.Size(43, 16)
        Me.lbComb2.TabIndex = 2
        Me.lbComb2.Text = "File 1:"
        '
        'File2Txb
        '
        Me.File2Txb.BackColor = System.Drawing.Color.White
        Me.File2Txb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.File2Txb.Location = New System.Drawing.Point(99, 136)
        Me.File2Txb.Name = "File2Txb"
        Me.File2Txb.Size = New System.Drawing.Size(375, 22)
        Me.File2Txb.TabIndex = 1
        Me.File2Txb.TabStop = False
        '
        'lbComb1
        '
        Me.lbComb1.AutoSize = True
        Me.lbComb1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbComb1.Location = New System.Drawing.Point(6, 28)
        Me.lbComb1.Name = "lbComb1"
        Me.lbComb1.Size = New System.Drawing.Size(505, 48)
        Me.lbComb1.TabIndex = 1
        Me.lbComb1.Text = resources.GetString("lbComb1.Text")
        '
        'File1Txb
        '
        Me.File1Txb.BackColor = System.Drawing.Color.White
        Me.File1Txb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.File1Txb.Location = New System.Drawing.Point(99, 108)
        Me.File1Txb.Name = "File1Txb"
        Me.File1Txb.Size = New System.Drawing.Size(375, 22)
        Me.File1Txb.TabIndex = 0
        Me.File1Txb.TabStop = False
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.Label1)
        Me.TabPage8.Controls.Add(Me.GroupBoxWordT3)
        Me.TabPage8.Controls.Add(Me.GroupBoxWordT2)
        Me.TabPage8.Controls.Add(Me.GroupBoxWordT1)
        Me.TabPage8.Controls.Add(Me.ListBoxWTL)
        Me.TabPage8.Location = New System.Drawing.Point(4, 24)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(794, 552)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "Wordlist-Tools"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(483, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(101, 15)
        Me.Label1.TabIndex = 66
        Me.Label1.Text = "Wordlist-Analyser"
        '
        'GroupBoxWordT3
        '
        Me.GroupBoxWordT3.Controls.Add(Me.cbWordScanner)
        Me.GroupBoxWordT3.Controls.Add(Me.Label63)
        Me.GroupBoxWordT3.Controls.Add(Me.pbWordScanner)
        Me.GroupBoxWordT3.Controls.Add(Me.Label64)
        Me.GroupBoxWordT3.Controls.Add(Me.tbWordScanner2)
        Me.GroupBoxWordT3.Controls.Add(Me.Label65)
        Me.GroupBoxWordT3.Controls.Add(Me.tbWordScanner)
        Me.GroupBoxWordT3.Controls.Add(Me.lbWordT3)
        Me.GroupBoxWordT3.Controls.Add(Me.btnWordScanner)
        Me.GroupBoxWordT3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxWordT3.Location = New System.Drawing.Point(15, 305)
        Me.GroupBoxWordT3.Name = "GroupBoxWordT3"
        Me.GroupBoxWordT3.Size = New System.Drawing.Size(443, 191)
        Me.GroupBoxWordT3.TabIndex = 65
        Me.GroupBoxWordT3.TabStop = False
        Me.GroupBoxWordT3.Text = "Wordlist Scanner"
        '
        'cbWordScanner
        '
        Me.cbWordScanner.AutoSize = True
        Me.cbWordScanner.Checked = True
        Me.cbWordScanner.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbWordScanner.Location = New System.Drawing.Point(93, 154)
        Me.cbWordScanner.Name = "cbWordScanner"
        Me.cbWordScanner.Size = New System.Drawing.Size(15, 14)
        Me.cbWordScanner.TabIndex = 29
        Me.cbWordScanner.UseVisualStyleBackColor = True
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.Location = New System.Drawing.Point(15, 154)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(67, 16)
        Me.Label63.TabIndex = 28
        Me.Label63.Text = "Line No.?:"
        '
        'pbWordScanner
        '
        Me.pbWordScanner.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pbWordScanner.Image = CType(resources.GetObject("pbWordScanner.Image"), System.Drawing.Image)
        Me.pbWordScanner.Location = New System.Drawing.Point(409, 127)
        Me.pbWordScanner.Name = "pbWordScanner"
        Me.pbWordScanner.Size = New System.Drawing.Size(25, 21)
        Me.pbWordScanner.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbWordScanner.TabIndex = 27
        Me.pbWordScanner.TabStop = False
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label64.Location = New System.Drawing.Point(15, 130)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(60, 16)
        Me.Label64.TabIndex = 8
        Me.Label64.Text = "Wordlist:"
        '
        'tbWordScanner2
        '
        Me.tbWordScanner2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWordScanner2.Location = New System.Drawing.Point(93, 127)
        Me.tbWordScanner2.Name = "tbWordScanner2"
        Me.tbWordScanner2.Size = New System.Drawing.Size(310, 22)
        Me.tbWordScanner2.TabIndex = 7
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label65.Location = New System.Drawing.Point(15, 103)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(63, 16)
        Me.Label65.TabIndex = 6
        Me.Label65.Text = "Keyword:"
        '
        'tbWordScanner
        '
        Me.tbWordScanner.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbWordScanner.Location = New System.Drawing.Point(93, 100)
        Me.tbWordScanner.Name = "tbWordScanner"
        Me.tbWordScanner.Size = New System.Drawing.Size(310, 22)
        Me.tbWordScanner.TabIndex = 5
        '
        'lbWordT3
        '
        Me.lbWordT3.AutoSize = True
        Me.lbWordT3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbWordT3.Location = New System.Drawing.Point(15, 27)
        Me.lbWordT3.Name = "lbWordT3"
        Me.lbWordT3.Size = New System.Drawing.Size(331, 48)
        Me.lbWordT3.TabIndex = 4
        Me.lbWordT3.Text = "The Wordlist Scanner searches wordlist for a Keyword " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and outputs the line numbe" &
    "r. You can find the file in " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "the folder ""#_Wordlist""."
        '
        'btnWordScanner
        '
        Me.btnWordScanner.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnWordScanner.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWordScanner.Location = New System.Drawing.Point(279, 154)
        Me.btnWordScanner.Name = "btnWordScanner"
        Me.btnWordScanner.Size = New System.Drawing.Size(124, 23)
        Me.btnWordScanner.TabIndex = 1
        Me.btnWordScanner.Text = "START"
        Me.btnWordScanner.UseVisualStyleBackColor = False
        '
        'GroupBoxWordT2
        '
        Me.GroupBoxWordT2.Controls.Add(Me.btnWordAnalyserEx)
        Me.GroupBoxWordT2.Controls.Add(Me.lbWordT2)
        Me.GroupBoxWordT2.Controls.Add(Me.btnWordAnalyser)
        Me.GroupBoxWordT2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxWordT2.Location = New System.Drawing.Point(16, 24)
        Me.GroupBoxWordT2.Name = "GroupBoxWordT2"
        Me.GroupBoxWordT2.Size = New System.Drawing.Size(443, 138)
        Me.GroupBoxWordT2.TabIndex = 64
        Me.GroupBoxWordT2.TabStop = False
        Me.GroupBoxWordT2.Text = "Wordlist Analyser"
        '
        'btnWordAnalyserEx
        '
        Me.btnWordAnalyserEx.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnWordAnalyserEx.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWordAnalyserEx.Location = New System.Drawing.Point(279, 109)
        Me.btnWordAnalyserEx.Name = "btnWordAnalyserEx"
        Me.btnWordAnalyserEx.Size = New System.Drawing.Size(124, 23)
        Me.btnWordAnalyserEx.TabIndex = 5
        Me.btnWordAnalyserEx.Text = "Export"
        Me.btnWordAnalyserEx.UseVisualStyleBackColor = False
        '
        'lbWordT2
        '
        Me.lbWordT2.AutoSize = True
        Me.lbWordT2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbWordT2.Location = New System.Drawing.Point(15, 27)
        Me.lbWordT2.Name = "lbWordT2"
        Me.lbWordT2.Size = New System.Drawing.Size(352, 48)
        Me.lbWordT2.TabIndex = 4
        Me.lbWordT2.Text = "The Wordlist Analyzer counts all characters in a wordlist." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "This allows frequentl" &
    "y used characters of the target person" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "to be detected."
        '
        'btnWordAnalyser
        '
        Me.btnWordAnalyser.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnWordAnalyser.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWordAnalyser.Location = New System.Drawing.Point(279, 80)
        Me.btnWordAnalyser.Name = "btnWordAnalyser"
        Me.btnWordAnalyser.Size = New System.Drawing.Size(124, 23)
        Me.btnWordAnalyser.TabIndex = 1
        Me.btnWordAnalyser.Text = "Wordlist Analyser"
        Me.btnWordAnalyser.UseVisualStyleBackColor = False
        '
        'GroupBoxWordT1
        '
        Me.GroupBoxWordT1.Controls.Add(Me.lbWordT1)
        Me.GroupBoxWordT1.Controls.Add(Me.btnWordMask)
        Me.GroupBoxWordT1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxWordT1.Location = New System.Drawing.Point(16, 168)
        Me.GroupBoxWordT1.Name = "GroupBoxWordT1"
        Me.GroupBoxWordT1.Size = New System.Drawing.Size(443, 131)
        Me.GroupBoxWordT1.TabIndex = 62
        Me.GroupBoxWordT1.TabStop = False
        Me.GroupBoxWordT1.Text = "Wordlist > Mask"
        '
        'lbWordT1
        '
        Me.lbWordT1.AutoSize = True
        Me.lbWordT1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbWordT1.Location = New System.Drawing.Point(15, 21)
        Me.lbWordT1.Name = "lbWordT1"
        Me.lbWordT1.Size = New System.Drawing.Size(320, 48)
        Me.lbWordT1.TabIndex = 3
        Me.lbWordT1.Text = "People often use the same password structure. " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "With this tool you can convert wo" &
    "rdlists into masklists " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(.hcmask)."
        '
        'btnWordMask
        '
        Me.btnWordMask.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnWordMask.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWordMask.Location = New System.Drawing.Point(279, 102)
        Me.btnWordMask.Name = "btnWordMask"
        Me.btnWordMask.Size = New System.Drawing.Size(124, 23)
        Me.btnWordMask.TabIndex = 2
        Me.btnWordMask.Text = "Wordlist > Mask"
        Me.btnWordMask.UseVisualStyleBackColor = False
        '
        'ListBoxWTL
        '
        Me.ListBoxWTL.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.ListBoxWTL.ForeColor = System.Drawing.Color.LawnGreen
        Me.ListBoxWTL.FormattingEnabled = True
        Me.ListBoxWTL.ItemHeight = 15
        Me.ListBoxWTL.Location = New System.Drawing.Point(486, 42)
        Me.ListBoxWTL.Name = "ListBoxWTL"
        Me.ListBoxWTL.Size = New System.Drawing.Size(192, 454)
        Me.ListBoxWTL.TabIndex = 61
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.GroupBox6)
        Me.TabPage9.Location = New System.Drawing.Point(4, 24)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(794, 552)
        Me.TabPage9.TabIndex = 8
        Me.TabPage9.Text = "DupCleaner"
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.lbDup1)
        Me.GroupBox6.Controls.Add(Me.Duptxb)
        Me.GroupBox6.Controls.Add(Me.btnDup)
        Me.GroupBox6.Controls.Add(Me.DupTargettxb)
        Me.GroupBox6.Controls.Add(Me.pbDup2)
        Me.GroupBox6.Controls.Add(Me.lbDup2)
        Me.GroupBox6.Controls.Add(Me.pbDup1)
        Me.GroupBox6.Controls.Add(Me.lbDup3)
        Me.GroupBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox6.Location = New System.Drawing.Point(16, 24)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(516, 177)
        Me.GroupBox6.TabIndex = 60
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "DupCleaner"
        '
        'lbDup1
        '
        Me.lbDup1.AutoSize = True
        Me.lbDup1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbDup1.Location = New System.Drawing.Point(6, 37)
        Me.lbDup1.Name = "lbDup1"
        Me.lbDup1.Size = New System.Drawing.Size(321, 16)
        Me.lbDup1.TabIndex = 0
        Me.lbDup1.Text = "DupCleaner removes duplicates from your Wordlists."
        '
        'Duptxb
        '
        Me.Duptxb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Duptxb.Location = New System.Drawing.Point(114, 76)
        Me.Duptxb.Name = "Duptxb"
        Me.Duptxb.Size = New System.Drawing.Size(349, 22)
        Me.Duptxb.TabIndex = 1
        '
        'btnDup
        '
        Me.btnDup.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnDup.Location = New System.Drawing.Point(388, 132)
        Me.btnDup.Name = "btnDup"
        Me.btnDup.Size = New System.Drawing.Size(75, 23)
        Me.btnDup.TabIndex = 34
        Me.btnDup.Text = "START"
        Me.btnDup.UseVisualStyleBackColor = False
        '
        'DupTargettxb
        '
        Me.DupTargettxb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DupTargettxb.Location = New System.Drawing.Point(114, 104)
        Me.DupTargettxb.Name = "DupTargettxb"
        Me.DupTargettxb.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DupTargettxb.Size = New System.Drawing.Size(349, 22)
        Me.DupTargettxb.TabIndex = 2
        '
        'pbDup2
        '
        Me.pbDup2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pbDup2.Image = CType(resources.GetObject("pbDup2.Image"), System.Drawing.Image)
        Me.pbDup2.Location = New System.Drawing.Point(469, 105)
        Me.pbDup2.Name = "pbDup2"
        Me.pbDup2.Size = New System.Drawing.Size(25, 21)
        Me.pbDup2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbDup2.TabIndex = 33
        Me.pbDup2.TabStop = False
        '
        'lbDup2
        '
        Me.lbDup2.AutoSize = True
        Me.lbDup2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbDup2.Location = New System.Drawing.Point(6, 79)
        Me.lbDup2.Name = "lbDup2"
        Me.lbDup2.Size = New System.Drawing.Size(94, 16)
        Me.lbDup2.TabIndex = 3
        Me.lbDup2.Text = "Wordlist folder"
        '
        'pbDup1
        '
        Me.pbDup1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pbDup1.Image = CType(resources.GetObject("pbDup1.Image"), System.Drawing.Image)
        Me.pbDup1.Location = New System.Drawing.Point(469, 77)
        Me.pbDup1.Name = "pbDup1"
        Me.pbDup1.Size = New System.Drawing.Size(25, 21)
        Me.pbDup1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbDup1.TabIndex = 32
        Me.pbDup1.TabStop = False
        '
        'lbDup3
        '
        Me.lbDup3.AutoSize = True
        Me.lbDup3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbDup3.Location = New System.Drawing.Point(6, 107)
        Me.lbDup3.Name = "lbDup3"
        Me.lbDup3.Size = New System.Drawing.Size(103, 16)
        Me.lbDup3.TabIndex = 4
        Me.lbDup3.Text = "Target directory"
        '
        'TabPage10
        '
        Me.TabPage10.Controls.Add(Me.GroupBox7)
        Me.TabPage10.Location = New System.Drawing.Point(4, 24)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage10.Size = New System.Drawing.Size(794, 552)
        Me.TabPage10.TabIndex = 9
        Me.TabPage10.Text = "HashGen"
        Me.TabPage10.UseVisualStyleBackColor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.LinkLabel1)
        Me.GroupBox7.Controls.Add(Me.lbHash2)
        Me.GroupBox7.Controls.Add(Me.lbHash1)
        Me.GroupBox7.Controls.Add(Me.lblHashGen)
        Me.GroupBox7.Controls.Add(Me.btnHashGen)
        Me.GroupBox7.Controls.Add(Me.HashIn)
        Me.GroupBox7.Controls.Add(Me.HashOUT)
        Me.GroupBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.Location = New System.Drawing.Point(24, 21)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(500, 247)
        Me.GroupBox7.TabIndex = 5
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Hash-Generator"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.Location = New System.Drawing.Point(8, 100)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(242, 16)
        Me.LinkLabel1.TabIndex = 5
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "https://www.webatic.com/md5-convertor"
        '
        'lbHash2
        '
        Me.lbHash2.AutoSize = True
        Me.lbHash2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbHash2.Location = New System.Drawing.Point(11, 184)
        Me.lbHash2.Name = "lbHash2"
        Me.lbHash2.Size = New System.Drawing.Size(43, 16)
        Me.lbHash2.TabIndex = 5
        Me.lbHash2.Text = "Hash:"
        '
        'lbHash1
        '
        Me.lbHash1.AutoSize = True
        Me.lbHash1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbHash1.Location = New System.Drawing.Point(11, 155)
        Me.lbHash1.Name = "lbHash1"
        Me.lbHash1.Size = New System.Drawing.Size(37, 16)
        Me.lbHash1.TabIndex = 4
        Me.lbHash1.Text = "Text:"
        '
        'lblHashGen
        '
        Me.lblHashGen.AutoSize = True
        Me.lblHashGen.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHashGen.Location = New System.Drawing.Point(8, 42)
        Me.lblHashGen.Name = "lblHashGen"
        Me.lblHashGen.Size = New System.Drawing.Size(462, 48)
        Me.lblHashGen.TabIndex = 2
        Me.lblHashGen.Text = "Here you can create a MD5-Hash for test purposes. The hash is saved in the " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "fold" &
    "er ""#_Hashout"". For special encoding (e.g. ISO-8859-1) you can use the" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "followin" &
    "g link:"
        '
        'btnHashGen
        '
        Me.btnHashGen.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHashGen.Location = New System.Drawing.Point(395, 206)
        Me.btnHashGen.Name = "btnHashGen"
        Me.btnHashGen.Size = New System.Drawing.Size(75, 23)
        Me.btnHashGen.TabIndex = 3
        Me.btnHashGen.Text = "START"
        Me.btnHashGen.UseVisualStyleBackColor = True
        '
        'HashIn
        '
        Me.HashIn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HashIn.Location = New System.Drawing.Point(59, 149)
        Me.HashIn.Name = "HashIn"
        Me.HashIn.Size = New System.Drawing.Size(411, 22)
        Me.HashIn.TabIndex = 0
        '
        'HashOUT
        '
        Me.HashOUT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HashOUT.Location = New System.Drawing.Point(59, 178)
        Me.HashOUT.Name = "HashOUT"
        Me.HashOUT.Size = New System.Drawing.Size(411, 22)
        Me.HashOUT.TabIndex = 1
        '
        'TabPage11
        '
        Me.TabPage11.Controls.Add(Me.GroupBox3)
        Me.TabPage11.Controls.Add(Me.GroupBoxBulk1)
        Me.TabPage11.Location = New System.Drawing.Point(4, 24)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage11.Size = New System.Drawing.Size(794, 552)
        Me.TabPage11.TabIndex = 10
        Me.TabPage11.Text = "BulkExtractor"
        Me.TabPage11.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.lbBulk)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(18, 24)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(649, 209)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Bulk Extractor"
        '
        'lbBulk
        '
        Me.lbBulk.AutoSize = True
        Me.lbBulk.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbBulk.Location = New System.Drawing.Point(16, 27)
        Me.lbBulk.Name = "lbBulk"
        Me.lbBulk.Size = New System.Drawing.Size(573, 128)
        Me.lbBulk.TabIndex = 0
        Me.lbBulk.Text = resources.GetString("lbBulk.Text")
        '
        'GroupBoxBulk1
        '
        Me.GroupBoxBulk1.Controls.Add(Me.pbBulk1)
        Me.GroupBoxBulk1.Controls.Add(Me.cbBulk1)
        Me.GroupBoxBulk1.Controls.Add(Me.cbBulk2)
        Me.GroupBoxBulk1.Controls.Add(Me.Label69)
        Me.GroupBoxBulk1.Controls.Add(Me.btnBulkStart)
        Me.GroupBoxBulk1.Controls.Add(Me.Label70)
        Me.GroupBoxBulk1.Controls.Add(Me.lbBulk1)
        Me.GroupBoxBulk1.Controls.Add(Me.tbBulkImage)
        Me.GroupBoxBulk1.Controls.Add(Me.tbBulkmax)
        Me.GroupBoxBulk1.Controls.Add(Me.lbBulk2)
        Me.GroupBoxBulk1.Controls.Add(Me.tbBulkmin)
        Me.GroupBoxBulk1.Controls.Add(Me.lbBulk3)
        Me.GroupBoxBulk1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxBulk1.Location = New System.Drawing.Point(18, 252)
        Me.GroupBoxBulk1.Name = "GroupBoxBulk1"
        Me.GroupBoxBulk1.Size = New System.Drawing.Size(649, 165)
        Me.GroupBoxBulk1.TabIndex = 2
        Me.GroupBoxBulk1.TabStop = False
        Me.GroupBoxBulk1.Text = "Parameter"
        '
        'pbBulk1
        '
        Me.pbBulk1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pbBulk1.Image = CType(resources.GetObject("pbBulk1.Image"), System.Drawing.Image)
        Me.pbBulk1.Location = New System.Drawing.Point(380, 68)
        Me.pbBulk1.Name = "pbBulk1"
        Me.pbBulk1.Size = New System.Drawing.Size(25, 21)
        Me.pbBulk1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbBulk1.TabIndex = 31
        Me.pbBulk1.TabStop = False
        '
        'cbBulk1
        '
        Me.cbBulk1.AutoSize = True
        Me.cbBulk1.Checked = True
        Me.cbBulk1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbBulk1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbBulk1.Location = New System.Drawing.Point(97, 32)
        Me.cbBulk1.Name = "cbBulk1"
        Me.cbBulk1.Size = New System.Drawing.Size(108, 20)
        Me.cbBulk1.TabIndex = 24
        Me.cbBulk1.TabStop = False
        Me.cbBulk1.Text = "Full extraction"
        Me.cbBulk1.UseVisualStyleBackColor = True
        '
        'cbBulk2
        '
        Me.cbBulk2.AutoSize = True
        Me.cbBulk2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbBulk2.Location = New System.Drawing.Point(211, 32)
        Me.cbBulk2.Name = "cbBulk2"
        Me.cbBulk2.Size = New System.Drawing.Size(104, 20)
        Me.cbBulk2.TabIndex = 23
        Me.cbBulk2.TabStop = False
        Me.cbBulk2.Text = "only Wordlist"
        Me.cbBulk2.UseVisualStyleBackColor = True
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label69.Location = New System.Drawing.Point(10, 32)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(81, 16)
        Me.Label69.TabIndex = 22
        Me.Label69.Text = "Parameters:"
        '
        'btnBulkStart
        '
        Me.btnBulkStart.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnBulkStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBulkStart.Location = New System.Drawing.Point(285, 114)
        Me.btnBulkStart.Name = "btnBulkStart"
        Me.btnBulkStart.Size = New System.Drawing.Size(89, 25)
        Me.btnBulkStart.TabIndex = 2
        Me.btnBulkStart.Text = "START"
        Me.btnBulkStart.UseVisualStyleBackColor = False
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label70.Location = New System.Drawing.Point(94, 92)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(162, 13)
        Me.Label70.TabIndex = 2
        Me.Label70.Text = "(Supported .dd, .001, .mem, etc.)"
        '
        'lbBulk1
        '
        Me.lbBulk1.AutoSize = True
        Me.lbBulk1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbBulk1.Location = New System.Drawing.Point(10, 71)
        Me.lbBulk1.Name = "lbBulk1"
        Me.lbBulk1.Size = New System.Drawing.Size(49, 16)
        Me.lbBulk1.TabIndex = 0
        Me.lbBulk1.Text = "Image:"
        '
        'tbBulkImage
        '
        Me.tbBulkImage.BackColor = System.Drawing.Color.White
        Me.tbBulkImage.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbBulkImage.Location = New System.Drawing.Point(97, 68)
        Me.tbBulkImage.Name = "tbBulkImage"
        Me.tbBulkImage.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.tbBulkImage.Size = New System.Drawing.Size(277, 22)
        Me.tbBulkImage.TabIndex = 1
        Me.tbBulkImage.TabStop = False
        '
        'tbBulkmax
        '
        Me.tbBulkmax.BackColor = System.Drawing.Color.White
        Me.tbBulkmax.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbBulkmax.Location = New System.Drawing.Point(195, 115)
        Me.tbBulkmax.Name = "tbBulkmax"
        Me.tbBulkmax.Size = New System.Drawing.Size(55, 21)
        Me.tbBulkmax.TabIndex = 7
        Me.tbBulkmax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbBulk2
        '
        Me.lbBulk2.AutoSize = True
        Me.lbBulk2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbBulk2.Location = New System.Drawing.Point(10, 118)
        Me.lbBulk2.Name = "lbBulk2"
        Me.lbBulk2.Size = New System.Drawing.Size(87, 16)
        Me.lbBulk2.TabIndex = 4
        Me.lbBulk2.Text = "Word Length:"
        '
        'tbBulkmin
        '
        Me.tbBulkmin.BackColor = System.Drawing.Color.White
        Me.tbBulkmin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbBulkmin.Location = New System.Drawing.Point(97, 115)
        Me.tbBulkmin.Name = "tbBulkmin"
        Me.tbBulkmin.Size = New System.Drawing.Size(55, 21)
        Me.tbBulkmin.TabIndex = 6
        Me.tbBulkmin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbBulk3
        '
        Me.lbBulk3.AutoSize = True
        Me.lbBulk3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbBulk3.Location = New System.Drawing.Point(158, 118)
        Me.lbBulk3.Name = "lbBulk3"
        Me.lbBulk3.Size = New System.Drawing.Size(31, 16)
        Me.lbBulk3.TabIndex = 5
        Me.lbBulk3.Text = "until"
        '
        'pbGER
        '
        Me.pbGER.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pbGER.Image = CType(resources.GetObject("pbGER.Image"), System.Drawing.Image)
        Me.pbGER.Location = New System.Drawing.Point(-11, 124)
        Me.pbGER.Name = "pbGER"
        Me.pbGER.Size = New System.Drawing.Size(76, 33)
        Me.pbGER.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbGER.TabIndex = 73
        Me.pbGER.TabStop = False
        '
        'pbENG
        '
        Me.pbENG.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pbENG.Image = CType(resources.GetObject("pbENG.Image"), System.Drawing.Image)
        Me.pbENG.Location = New System.Drawing.Point(-11, 85)
        Me.pbENG.Name = "pbENG"
        Me.pbENG.Size = New System.Drawing.Size(76, 32)
        Me.pbENG.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbENG.TabIndex = 74
        Me.pbENG.TabStop = False
        '
        'pbAbout
        '
        Me.pbAbout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pbAbout.Image = CType(resources.GetObject("pbAbout.Image"), System.Drawing.Image)
        Me.pbAbout.Location = New System.Drawing.Point(12, 163)
        Me.pbAbout.Name = "pbAbout"
        Me.pbAbout.Size = New System.Drawing.Size(34, 31)
        Me.pbAbout.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbAbout.TabIndex = 70
        Me.pbAbout.TabStop = False
        '
        'pbGovC
        '
        Me.pbGovC.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pbGovC.Image = CType(resources.GetObject("pbGovC.Image"), System.Drawing.Image)
        Me.pbGovC.Location = New System.Drawing.Point(1, 34)
        Me.pbGovC.Name = "pbGovC"
        Me.pbGovC.Size = New System.Drawing.Size(55, 55)
        Me.pbGovC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbGovC.TabIndex = 75
        Me.pbGovC.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(-7, 276)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(58, 313)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 70
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(0, 245)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(51, 80)
        Me.PictureBox3.TabIndex = 8
        Me.PictureBox3.TabStop = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'PictureBox6
        '
        Me.PictureBox6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox6.Image = CType(resources.GetObject("PictureBox6.Image"), System.Drawing.Image)
        Me.PictureBox6.Location = New System.Drawing.Point(12, 200)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(28, 39)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox6.TabIndex = 76
        Me.PictureBox6.TabStop = False
        '
        'GovTools
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(842, 571)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.Radar)
        Me.Controls.Add(Me.pbAbout)
        Me.Controls.Add(Me.pbTrash)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.pbENG)
        Me.Controls.Add(Me.pbGER)
        Me.Controls.Add(Me.pbGovC)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "GovTools"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GovTools"
        CType(Me.Radar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbTrash, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage7.ResumeLayout(False)
        Me.GroupBox23.ResumeLayout(False)
        Me.GroupBox23.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.GroupBoxPrince2.ResumeLayout(False)
        Me.GroupBoxPrince2.PerformLayout()
        Me.GroupBoxPrince1.ResumeLayout(False)
        Me.GroupBoxPrince1.PerformLayout()
        Me.GroupBoxPrince3.ResumeLayout(False)
        Me.GroupBoxPrince3.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.GroupBoxCUPP.ResumeLayout(False)
        Me.GroupBoxCUPP.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.GroupBoxWord3.ResumeLayout(False)
        Me.GroupBoxWord3.PerformLayout()
        Me.GroupBoxWord4.ResumeLayout(False)
        Me.GroupBoxWord4.PerformLayout()
        Me.GroupBoxWord2.ResumeLayout(False)
        Me.GroupBoxWord2.PerformLayout()
        Me.GroupBoxWord1.ResumeLayout(False)
        Me.GroupBoxWord1.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.GroupBoxcewl2.ResumeLayout(False)
        Me.GroupBoxcewl2.PerformLayout()
        Me.GroupBoxCewl1.ResumeLayout(False)
        Me.GroupBoxCewl1.PerformLayout()
        Me.GroupBoxcewl3.ResumeLayout(False)
        Me.GroupBoxcewl3.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.GroupBoxComb2.ResumeLayout(False)
        Me.GroupBoxComb2.PerformLayout()
        CType(Me.pbLen, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBoxComb1.ResumeLayout(False)
        Me.GroupBoxComb1.PerformLayout()
        CType(Me.pbCombinator3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbCombinator2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbCombinator1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout()
        Me.GroupBoxWordT3.ResumeLayout(False)
        Me.GroupBoxWordT3.PerformLayout()
        CType(Me.pbWordScanner, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBoxWordT2.ResumeLayout(False)
        Me.GroupBoxWordT2.PerformLayout()
        Me.GroupBoxWordT1.ResumeLayout(False)
        Me.GroupBoxWordT1.PerformLayout()
        Me.TabPage9.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.pbDup2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbDup1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage10.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.TabPage11.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBoxBulk1.ResumeLayout(False)
        Me.GroupBoxBulk1.PerformLayout()
        CType(Me.pbBulk1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbGER, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbENG, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbAbout, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbGovC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Radar As PictureBox
    Friend WithEvents pbTrash As PictureBox
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents lbMask1 As Label
    Friend WithEvents tbMaskPara As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lbMask10 As Label
    Friend WithEvents tbMask11 As TextBox
    Friend WithEvents tbMask12 As TextBox
    Friend WithEvents lbMask11 As Label
    Friend WithEvents lbMask14 As Label
    Friend WithEvents lbMask12 As Label
    Friend WithEvents lbMask2 As Label
    Friend WithEvents tbMask14 As TextBox
    Friend WithEvents cbMask2 As CheckBox
    Friend WithEvents tbMask13 As TextBox
    Friend WithEvents cbMask1 As CheckBox
    Friend WithEvents lbMask15 As Label
    Friend WithEvents lbMask8 As Label
    Friend WithEvents lbMask13 As Label
    Friend WithEvents tbMask8 As TextBox
    Friend WithEvents lbMask7 As Label
    Friend WithEvents tbMask9 As TextBox
    Friend WithEvents lbMask6 As Label
    Friend WithEvents lbMask9 As Label
    Friend WithEvents lbMask5 As Label
    Friend WithEvents cbMask4 As CheckBox
    Friend WithEvents lbMask4 As Label
    Friend WithEvents lbMask3 As Label
    Friend WithEvents tbMask6 As TextBox
    Friend WithEvents cbMask3 As CheckBox
    Friend WithEvents tbMask5 As TextBox
    Friend WithEvents tbMask3 As TextBox
    Friend WithEvents tbMask4 As TextBox
    Friend WithEvents btnMaskStart As Button
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents GroupBoxPrince2 As GroupBox
    Friend WithEvents lbPrinceMB As Label
    Friend WithEvents lbPrincePass As Label
    Friend WithEvents tbPRINCEMB As TextBox
    Friend WithEvents tbPRINCEPass As TextBox
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents btnPrinceCalc As Button
    Friend WithEvents labPrince As Label
    Friend WithEvents GroupBoxPrince1 As GroupBox
    Friend WithEvents Label31 As Label
    Friend WithEvents CheckBoxPrince As CheckBox
    Friend WithEvents lbprince2 As Label
    Friend WithEvents lbPrincemin As Label
    Friend WithEvents lbPrincemax As Label
    Friend WithEvents lbPrincemin2 As Label
    Friend WithEvents lbPrincemax2 As Label
    Friend WithEvents lbPrince1 As Label
    Friend WithEvents tbPrinceMinLen As TextBox
    Friend WithEvents tbPrinceMaxLen As TextBox
    Friend WithEvents tbPrinceMinPerm As TextBox
    Friend WithEvents tbPrinceMaxPerm As TextBox
    Friend WithEvents GroupBoxPrince3 As GroupBox
    Friend WithEvents btnPrinceDefault As Button
    Friend WithEvents btnPrinceFile As Button
    Friend WithEvents tbPrince As TextBox
    Friend WithEvents btnPrinceSTART As Button
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents GroupBoxWord3 As GroupBox
    Friend WithEvents Up As CheckBox
    Friend WithEvents Cap As CheckBox
    Friend WithEvents Leet As CheckBox
    Friend WithEvents lbWordall As Label
    Friend WithEvents lbWordfirst As Label
    Friend WithEvents lbWordleet As Label
    Friend WithEvents lbWordmax As Label
    Friend WithEvents lbWordmin As Label
    Friend WithEvents lbWordperm As Label
    Friend WithEvents Perm As TextBox
    Friend WithEvents MinL As TextBox
    Friend WithEvents MaxL As TextBox
    Friend WithEvents GroupBoxWord4 As GroupBox
    Friend WithEvents tbWordStandard As TextBox
    Friend WithEvents GroupBoxWord2 As GroupBox
    Friend WithEvents tbWord45 As TextBox
    Friend WithEvents tbWord40 As TextBox
    Friend WithEvents lbWordInfos As Label
    Friend WithEvents tbWord36 As TextBox
    Friend WithEvents tbWord44 As TextBox
    Friend WithEvents tbWord37 As TextBox
    Friend WithEvents tbWord38 As TextBox
    Friend WithEvents tbWord43 As TextBox
    Friend WithEvents tbWord39 As TextBox
    Friend WithEvents tbWord42 As TextBox
    Friend WithEvents tbWord41 As TextBox
    Friend WithEvents GroupBoxWord1 As GroupBox
    Friend WithEvents lbWord1 As Label
    Friend WithEvents tbWord35 As TextBox
    Friend WithEvents tbWord30 As TextBox
    Friend WithEvents tbWord25 As TextBox
    Friend WithEvents lbWordBirthyear As Label
    Friend WithEvents tbWord20 As TextBox
    Friend WithEvents tbWord34 As TextBox
    Friend WithEvents tbWord29 As TextBox
    Friend WithEvents tbWord24 As TextBox
    Friend WithEvents tbWord19 As TextBox
    Friend WithEvents tbWord14 As TextBox
    Friend WithEvents tbWord9 As TextBox
    Friend WithEvents tbWord4 As TextBox
    Friend WithEvents lbWordBirthday As Label
    Friend WithEvents tbWord15 As TextBox
    Friend WithEvents tbWord33 As TextBox
    Friend WithEvents tbWord28 As TextBox
    Friend WithEvents tbWord23 As TextBox
    Friend WithEvents tbWord18 As TextBox
    Friend WithEvents tbWord13 As TextBox
    Friend WithEvents tbWord8 As TextBox
    Friend WithEvents tbWord3 As TextBox
    Friend WithEvents lbWordSurname As Label
    Friend WithEvents tbWord10 As TextBox
    Friend WithEvents tbWord32 As TextBox
    Friend WithEvents tbWord27 As TextBox
    Friend WithEvents tbWord22 As TextBox
    Friend WithEvents tbWord17 As TextBox
    Friend WithEvents tbWord12 As TextBox
    Friend WithEvents tbWord7 As TextBox
    Friend WithEvents tbWord2 As TextBox
    Friend WithEvents lbWordName As Label
    Friend WithEvents lbWordNickname As Label
    Friend WithEvents tbWord5 As TextBox
    Friend WithEvents tbWord31 As TextBox
    Friend WithEvents tbWord26 As TextBox
    Friend WithEvents tbWord21 As TextBox
    Friend WithEvents tbWord16 As TextBox
    Friend WithEvents tbWord11 As TextBox
    Friend WithEvents tbWord6 As TextBox
    Friend WithEvents lbWordFather As Label
    Friend WithEvents lbWordMother As Label
    Friend WithEvents lbWordChild3 As Label
    Friend WithEvents lbWordChild2 As Label
    Friend WithEvents lbWordChild1 As Label
    Friend WithEvents lbWordWife As Label
    Friend WithEvents lbWordTarget As Label
    Friend WithEvents tbWord1 As TextBox
    Friend WithEvents btnWordOpen As Button
    Friend WithEvents btnWordStart As Button
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents GroupBoxcewl2 As GroupBox
    Friend WithEvents lbcewl3 As Label
    Friend WithEvents tbCewlPage As TextBox
    Friend WithEvents lbcewl2 As Label
    Friend WithEvents GroupBoxCewl1 As GroupBox
    Friend WithEvents lbCewl1 As Label
    Friend WithEvents btnCewlLinux As Button
    Friend WithEvents btnCewlStart As Button
    Friend WithEvents GroupBoxcewl3 As GroupBox
    Friend WithEvents lbcewl4 As Label
    Friend WithEvents lbcewl5 As Label
    Friend WithEvents tbCewlWord As TextBox
    Friend WithEvents tbCewlSpider As TextBox
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents GroupBoxComb2 As GroupBox
    Friend WithEvents pbLen As PictureBox
    Friend WithEvents lbLen4 As Label
    Friend WithEvents LenMaxTxb As TextBox
    Friend WithEvents btnLen As Button
    Friend WithEvents lbLen3 As Label
    Friend WithEvents lbLen2 As Label
    Friend WithEvents LenMinTxb As TextBox
    Friend WithEvents lbLen1 As Label
    Friend WithEvents LenTxb As TextBox
    Friend WithEvents GroupBoxComb1 As GroupBox
    Friend WithEvents pbCombinator3 As PictureBox
    Friend WithEvents pbCombinator2 As PictureBox
    Friend WithEvents pbCombinator1 As PictureBox
    Friend WithEvents lbComb4 As Label
    Friend WithEvents File3Txb As TextBox
    Friend WithEvents btnCombinator As Button
    Friend WithEvents lbComb3 As Label
    Friend WithEvents lbComb2 As Label
    Friend WithEvents File2Txb As TextBox
    Friend WithEvents lbComb1 As Label
    Friend WithEvents File1Txb As TextBox
    Friend WithEvents TabPage8 As TabPage
    Friend WithEvents GroupBoxWordT3 As GroupBox
    Friend WithEvents cbWordScanner As CheckBox
    Friend WithEvents Label63 As Label
    Friend WithEvents pbWordScanner As PictureBox
    Friend WithEvents Label64 As Label
    Friend WithEvents tbWordScanner2 As TextBox
    Friend WithEvents Label65 As Label
    Friend WithEvents tbWordScanner As TextBox
    Friend WithEvents lbWordT3 As Label
    Friend WithEvents btnWordScanner As Button
    Friend WithEvents GroupBoxWordT2 As GroupBox
    Friend WithEvents btnWordAnalyserEx As Button
    Friend WithEvents lbWordT2 As Label
    Friend WithEvents btnWordAnalyser As Button
    Friend WithEvents GroupBoxWordT1 As GroupBox
    Friend WithEvents lbWordT1 As Label
    Friend WithEvents btnWordMask As Button
    Friend WithEvents ListBoxWTL As ListBox
    Friend WithEvents TabPage9 As TabPage
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents lbDup1 As Label
    Friend WithEvents Duptxb As TextBox
    Friend WithEvents btnDup As Button
    Friend WithEvents DupTargettxb As TextBox
    Friend WithEvents pbDup2 As PictureBox
    Friend WithEvents lbDup2 As Label
    Friend WithEvents pbDup1 As PictureBox
    Friend WithEvents lbDup3 As Label
    Friend WithEvents TabPage10 As TabPage
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents lbHash2 As Label
    Friend WithEvents lbHash1 As Label
    Friend WithEvents lblHashGen As Label
    Friend WithEvents btnHashGen As Button
    Friend WithEvents HashIn As TextBox
    Friend WithEvents HashOUT As TextBox
    Friend WithEvents TabPage11 As TabPage
    Friend WithEvents GroupBoxBulk1 As GroupBox
    Friend WithEvents pbBulk1 As PictureBox
    Friend WithEvents cbBulk1 As CheckBox
    Friend WithEvents cbBulk2 As CheckBox
    Friend WithEvents Label69 As Label
    Friend WithEvents btnBulkStart As Button
    Friend WithEvents Label70 As Label
    Friend WithEvents lbBulk1 As Label
    Friend WithEvents tbBulkImage As TextBox
    Friend WithEvents tbBulkmax As TextBox
    Friend WithEvents lbBulk2 As Label
    Friend WithEvents tbBulkmin As TextBox
    Friend WithEvents lbBulk3 As Label
    Friend WithEvents pbGER As PictureBox
    Friend WithEvents pbENG As PictureBox
    Friend WithEvents GroupBoxCUPP As GroupBox
    Friend WithEvents lbCupp1 As Label
    Friend WithEvents btnCupp As Button
    Friend WithEvents pbAbout As PictureBox
    Friend WithEvents lbCewlInstall As Label
    Friend WithEvents btnCewlInstall As Button
    Friend WithEvents pbGovC As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents GroupBox23 As GroupBox
    Friend WithEvents LinkEx1 As LinkLabel
    Friend WithEvents cbEx As ComboBox
    Friend WithEvents lbEx1 As Label
    Friend WithEvents btnEx As Button
    Friend WithEvents btnExFile As Button
    Friend WithEvents tbEx As TextBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents Label1 As Label
    Friend WithEvents lbMask16 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents lbBulk As Label
    Friend WithEvents PictureBox6 As PictureBox
End Class
